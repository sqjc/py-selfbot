# cogs/loggers.py | message / deleted / edited / reaction / mention / dm / join / leave loggers
#                   + centralized Components V2 webhook audit logger
import asyncio
import os
import sys
import time
from datetime import datetime
import aiohttp
import modifyself_shim as discord
from . import state as S


# ─────────────────────────────────────────────
# Components V2 webhook audit logger
# ─────────────────────────────────────────────
# Discord message flag: a message carrying Components V2 must set this bit and
# must NOT carry a plain `content` field.
_IS_COMPONENTS_V2 = 1 << 15
_MAX_TEXT = 3900          # keep the whole payload under the 4000-char body cap
_MAX_QUEUE = 200          # bounded so a dead webhook cannot eat memory
_MAX_ATTEMPTS = 3

_ACCENT = {
    "ok":   0x57F287,     # green
    "err":  0xED4245,     # red
    "info": 0x5865F2,     # blurple
}
_BUTTON = {
    "ok":   "OK",
    "err":  "ERROR",
    "info": "INFO",
}

_audit_queue: "asyncio.Queue" = None
_audit_task = None


def _webhook_url():
    """Reuse the existing .setwebhook destination; env var is the fallback."""
    u = None
    try:
        u = (S.meta or {}).get("webhook")
    except Exception:
        u = None
    if not u:
        u = os.environ.get("LOG_WEBHOOK_URL") or None
    return u


def _redact(text):
    """Never ship tokens or webhook URLs into a log sink."""
    return S.redact_secrets(text)


def _td(content):
    """Text display (type 10) — the only component that carries text."""
    return {"type": 10, "content": str(content)[:_MAX_TEXT]}


def _sep():
    """Separator (type 14)."""
    return {"type": 14, "divider": True, "spacing": 1}


def _btn(label):
    """Button (type 2), secondary style, label only — no emoji dependency."""
    return {"type": 2, "style": 2, "label": str(label)[:32],
            "custom_id": "wilt.audit"}


def _section(text, accessory=None):
    """Section (type 1): exactly one text display + optional accessory."""
    c = {"type": 1, "components": [_td(text)]}
    if accessory:
        c["accessory"] = accessory
    return c


def _container(children, accent):
    """Container (type 17) — wraps the whole record."""
    c = {"type": 17, "components": children}
    if accent is not None:
        c["accent_color"] = int(accent)
    return c


def build_payload(title, fields, status="info", accent=None):
    """
    Compose a single-container Components V2 message.

    title  – heading line
    fields – list of (label, value) pairs, already caller-formatted
    status – 'ok' | 'err' | 'info'  (drives button label + default accent)
    accent – optional override colour (int)
    """
    status = status if status in _ACCENT else "info"
    if accent is None:
        accent = _ACCENT[status]

    lines = [f"**{_redact(title)}**"]
    for label, value in fields:
        lab = _redact(label)
        val = _redact(value)
        if val == "":
            lines.append(f"**{lab}**")
        else:
            lines.append(f"**{lab}:** {val}")
    body = "\n".join(lines)
    if len(body) > _MAX_TEXT:
        body = body[:_MAX_TEXT - 1] + "…"

    kids = [_td(body), _sep(), _section(_redact(status.upper()), _btn(_BUTTON[status]))]
    return {"flags": _IS_COMPONENTS_V2, "components": [_container(kids, accent)]}


async def _audit_worker():
    global _audit_queue
    while True:
        try:
            payload = await _audit_queue.get()
        except asyncio.CancelledError:
            raise
        except Exception:
            await asyncio.sleep(0.5)
            continue
        url = _webhook_url()
        if not url:
            continue
        for attempt in range(_MAX_ATTEMPTS):
            try:
                async with aiohttp.ClientSession() as s:
                    async with s.post(
                        url, json=payload,
                        headers={"User-Agent": S.USER_AGENT},
                    ) as r:
                        if r.status == 429:
                            try:
                                info = await r.json()
                                wait = float(info.get("retry_after", 1.0))
                            except Exception:
                                wait = 1.0
                            await asyncio.sleep(max(0.5, min(wait, 30.0)))
                            continue
                        if r.status in (200, 204):
                            break
                        if 400 <= r.status < 500:
                            break          # our fault — retrying will not help
                        await asyncio.sleep(1.5 * (attempt + 1))
            except asyncio.CancelledError:
                raise
            except Exception:
                if attempt == _MAX_ATTEMPTS - 1:
                    break
                await asyncio.sleep(1.5 * (attempt + 1))


def log_event(title, fields, status="info", accent=None):
    """Fire-and-forget audit record. Safe to call from anywhere, any time."""
    global _audit_queue
    if _audit_queue is None:
        return
    try:
        _audit_queue.put_nowait(build_payload(title, fields, status, accent))
    except Exception:
        pass


def start_audit_worker():
    global _audit_queue, _audit_task
    if _audit_queue is None:
        _audit_queue = asyncio.Queue(maxsize=_MAX_QUEUE)
    if _audit_task is None or _audit_task.done():
        _audit_task = asyncio.get_running_loop().create_task(_audit_worker())
    return _audit_task


def _sync(**kw):
    main = sys.modules.get("__main__")
    if main is None:
        return
    for k, v in kw.items():
        try:
            setattr(main, k, v)
        except Exception:
            pass


def _log_ch(client, kind):
    ch_id = S.loggers.get(kind, {}).get("channel")
    if not ch_id:
        return None
    try:
        return client.get_channel(int(ch_id))
    except Exception:
        return None


def _fmt_time():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _mentions_self(client, m):
    try:
        if client.user and any(
                getattr(u, "id", None) == client.user.id for u in (m.mentions or [])):
            return True
    except Exception:
        pass
    try:
        raw = getattr(m, "raw_mentions", None)
        if raw and client.user and client.user.id in raw:
            return True
    except Exception:
        pass
    return False


async def _emit(client, kind, title, rows):
    ch = _log_ch(client, kind)
    if not ch:
        return
    try:
        await ch.send(S.ui_box(title, rows))
    except Exception:
        pass


class LoggersCog:
    COMMANDS = {"logger", "logchannel", "logstatus",
                "logmessage", "logdeleted", "logedited", "logreaction",
                "logmention", "logdm", "logjoins", "logleaves"}

    def register(self, client):
        cog = self
        try:
            S.log_event = log_event
        except Exception:
            pass
        try:
            start_audit_worker()
        except Exception:
            pass

        @client.event
        async def on_message(m):
            if getattr(m.author, "id", None) == client.user.id: return
            if S.loggers["mention"]["enabled"] and _mentions_self(client, m):
                await cog._mention(m)
            if S.loggers["dm"]["enabled"] and getattr(m, "guild", None) is None:
                await cog._dm(m)
            if not S.loggers["message"]["enabled"]: return
            await cog._message(m)

        @client.event
        async def on_message_delete(m):
            if not S.loggers["deleted"]["enabled"]: return
            if getattr(m.author, "id", None) == client.user.id: return
            await cog._deleted(m)

        @client.event
        async def on_message_edit(before, after):
            if not S.loggers["edited"]["enabled"]: return
            if getattr(before.author, "id", None) == client.user.id: return
            if (before.content or "") == (after.content or ""): return
            await cog._edited(before, after)

        @client.event
        async def on_reaction_add(reaction, user):
            if not S.loggers["reaction"]["enabled"]: return
            if getattr(user, "id", None) == client.user.id: return
            await cog._reaction(reaction, user, add=True)

        @client.event
        async def on_reaction_remove(reaction, user):
            if not S.loggers["reaction"]["enabled"]: return
            if getattr(user, "id", None) == client.user.id: return
            await cog._reaction(reaction, user, add=False)

        @client.event
        async def on_member_join(member):
            if not S.loggers["joins"]["enabled"]: return
            await _emit(client, "joins", "member join", [
                f"  {S.DIM}user{S.RESET}  {member}  ({getattr(member, 'id', '?')})",
                f"  {S.DIM}guild{S.RESET} {getattr(getattr(member, 'guild', None), 'name', '?')}",
                f"  {S.DIM}at{S.RESET}    {_fmt_time()}",
            ])

        @client.event
        async def on_member_remove(member):
            if not S.loggers["leaves"]["enabled"]: return
            await _emit(client, "leaves", "member leave", [
                f"  {S.DIM}user{S.RESET}  {member}  ({getattr(member, 'id', '?')})",
                f"  {S.DIM}guild{S.RESET} {getattr(getattr(member, 'guild', None), 'name', '?')}",
                f"  {S.DIM}at{S.RESET}    {_fmt_time()}",
            ])

    async def _message(self, m):
        g = getattr(m, "guild", None)
        rows = [
            f"  {S.DIM}guild{S.RESET}   {getattr(g, 'name', 'DM')}",
            f"  {S.DIM}channel{S.RESET} {getattr(m.channel, 'name', str(m.channel_id))}",
            f"  {S.DIM}author{S.RESET}  {m.author}  ({getattr(m.author,'id','?')})",
            f"  {S.DIM}at{S.RESET}      {_fmt_time()}",
            "",
            f"  {S.WHITE}{(m.content or '')[:400]}{S.RESET}",
        ]
        await _emit(S.CLIENT, "message", "message", rows)

    async def _mention(self, m):
        g = getattr(m, "guild", None)
        rows = [
            f"  {S.DIM}guild{S.RESET}   {getattr(g, 'name', 'DM')}",
            f"  {S.DIM}channel{S.RESET} {getattr(m.channel, 'name', str(m.channel_id))}",
            f"  {S.DIM}author{S.RESET}  {m.author}  ({getattr(m.author,'id','?')})",
            f"  {S.DIM}at{S.RESET}      {_fmt_time()}",
            "",
            f"  {S.WHITE}{(m.content or '')[:400]}{S.RESET}",
        ]
        await _emit(S.CLIENT, "mention", "mention", rows)

    async def _dm(self, m):
        rows = [
            f"  {S.DIM}author{S.RESET}  {m.author}  ({getattr(m.author,'id','?')})",
            f"  {S.DIM}at{S.RESET}      {_fmt_time()}",
            "",
            f"  {S.WHITE}{(m.content or '')[:400]}{S.RESET}",
        ]
        await _emit(S.CLIENT, "dm", "dm", rows)

    async def _deleted(self, m):
        atts = [a.get("url") for a in (m.attachments or [])]
        rows = [
            f"  {S.DIM}author{S.RESET}  {m.author}  ({getattr(m.author,'id','?')})",
            f"  {S.DIM}channel{S.RESET} {getattr(m.channel, 'name', str(m.channel_id))}",
            f"  {S.DIM}at{S.RESET}      {_fmt_time()}",
        ]
        if atts:
            rows.append(f"  {S.DIM}attach{S.RESET}  {', '.join(atts)}")
        rows += ["", f"  {S.WHITE}{(m.content or '')[:400]}{S.RESET}"]
        await _emit(S.CLIENT, "deleted", "message deleted", rows)

    async def _edited(self, before, after):
        rows = [
            f"  {S.DIM}author{S.RESET}  {before.author}  ({getattr(before.author,'id','?')})",
            f"  {S.DIM}channel{S.RESET} {getattr(before.channel, 'name', str(before.channel_id))}",
            f"  {S.DIM}at{S.RESET}      {_fmt_time()}",
            "",
            f"  {S.DIM}before{S.RESET}",
            f"  {S.WHITE}{(before.content or '')[:400]}{S.RESET}",
            "",
            f"  {S.DIM}after{S.RESET}",
            f"  {S.WHITE}{(after.content or '')[:400]}{S.RESET}",
        ]
        await _emit(S.CLIENT, "edited", "message edited", rows)

    async def _reaction(self, reaction, user, add=True):
        try:
            msg = reaction.message
        except Exception:
            return
        rows = [
            f"  {S.DIM}user{S.RESET}    {user}  ({getattr(user,'id','?')})",
            f"  {S.DIM}emoji{S.RESET}   {reaction.emoji}",
            f"  {S.DIM}action{S.RESET}  {'added' if add else 'removed'}",
            f"  {S.DIM}channel{S.RESET} {getattr(msg.channel, 'name', str(getattr(msg,'channel_id','?')))}",
            f"  {S.DIM}at{S.RESET}      {_fmt_time()}",
            "",
            f"  {S.WHITE}{(getattr(msg, 'content', '') or '')[:200]}{S.RESET}",
        ]
        await _emit(S.CLIENT, "reaction", "reaction", rows)

    async def handle(self, message, cmd, args):
        if cmd == "logger":
            sub = args[1].lower() if len(args) > 1 else ""
            kinds = list(S.loggers.keys())
            if sub in kinds:
                kind = sub
                on = (args[2].lower() in ("on", "enable")) if len(args) > 2 else not S.loggers[kind]["enabled"]
                S.loggers[kind]["enabled"] = on
                return await message.edit(content=S.ui_ok(f"{kind} logger → {on}"))
            if sub == "all":
                on = (args[2].lower() in ("on", "enable")) if len(args) > 2 else True
                for k in kinds:
                    S.loggers[k]["enabled"] = on
                return await message.edit(content=S.ui_ok(f"all loggers → {on}"))
            if sub in ("on", "off", "enable", "disable"):
                S.LOGGER_ENABLED = sub in ("on", "enable")
                _sync(LOGGER_ENABLED=S.LOGGER_ENABLED)
                return await message.edit(content=S.ui_ok(
                    f"logger → {'ON' if S.LOGGER_ENABLED else 'OFF'}"))
            rows = [f"  {S.DIM}{k:<10}{S.RESET}  {'ON' if v['enabled'] else 'off'}  "
                    f"{S.DIM}{v['channel'] or '—'}{S.RESET}" for k, v in S.loggers.items()]
            return await message.edit(content=S.ui_box("loggers", rows))

        if cmd == "logchannel":
            if len(args) < 3:
                return await message.edit(content=S.ui_err("usage: logchannel <kind> <ch_id>"))
            kind = args[1].lower()
            if kind not in S.loggers:
                return await message.edit(content=S.ui_err(f"unknown kind: {kind}"))
            S.loggers[kind]["channel"] = args[2]
            await message.edit(content=S.ui_ok(f"{kind} → {args[2]}"))

        if cmd == "logstatus":
            rows = [f"  {S.DIM}{k:<10}{S.RESET}  {'ON ' if v['enabled'] else 'off'}  ch {v['channel'] or '—'}"
                    for k, v in S.loggers.items()]
            await message.edit(content=S.ui_box("loggers status", rows))

        elif cmd.startswith("log") and cmd[3:] in S.loggers:
            kind = cmd[3:]
            on = (args[1].lower() in ("on", "enable")) if len(args) > 1 else not S.loggers[kind]["enabled"]
            S.loggers[kind]["enabled"] = on
            await message.edit(content=S.ui_ok(f"{kind} → {on}"))