# multi.py | run one full selfbot instance per main token
# config.json: "token" = first instance, "tokens": [...] = additional instances.
# Each instance gets its own working dir (instances/tN) with isolated data
# (database/, config.json, plugins/, ...) while sharing the live code here.
import json
import os
import shutil
import signal
import subprocess
import sys
import threading
from pathlib import Path

APP = Path(__file__).resolve().parent
INST = APP / "instances"
SKIP_DIRS = {"instances", "__pycache__", ".git", "venv", ".venv",
             "backups", "exports"}
SKIP_FILES = {"x-main.zip"}
EMPTY = {"", "YOUR_TOKEN_HERE", "None"}


def load_cfg():
    with open(APP / "config.json", encoding="utf-8") as f:
        return json.load(f)


def tokens_of(cfg):
    out, seen = [], set()
    for t in [cfg.get("token")] + list(cfg.get("tokens") or []):
        t = str(t or "").strip()
        if t in EMPTY or t in seen:
            continue
        seen.add(t)
        out.append(t)
    return out


def mask(t):
    return f"{t[:10]}...{t[-5:]}" if len(t) > 15 else f"{str(t)[:4]}..."


def prepare(idx, tok, cfg):
    d = INST / f"t{idx + 1}"
    if not d.exists():
        def ign(_dir, names):
            return [n for n in names if n in SKIP_DIRS or n in SKIP_FILES]
        shutil.copytree(APP, d, ignore=ign)
        for extra in ("backups", "exports"):
            (d / extra).mkdir(exist_ok=True)
        print(f"[multi] prepared instances/{d.name}")
    own = dict(cfg)
    own["token"] = tok
    own.pop("tokens", None)
    with open(d / "config.json", "w", encoding="utf-8") as f:
        json.dump(own, f, indent=4)
    return d


def relay(label, p):
    try:
        for line in p.stdout:
            print(f"[{label}] {line}", end="", flush=True)
    except Exception:
        pass


def main(cfg=None):
    try:
        sys.stdout.reconfigure(line_buffering=True)
    except Exception:
        pass
    dry = "--dry-run" in sys.argv[1:]
    cfg = cfg if isinstance(cfg, dict) else load_cfg()
    toks = tokens_of(cfg)
    if not toks:
        print("[multi] no token found in config.json")
        return 1
    print(f"[multi] {len(toks)} token(s) -> {len(toks)} instance(s)")
    procs, threads = [], []
    stopped = False
    try:
        for i, tok in enumerate(toks):
            label = f"t{i + 1}"
            if dry:
                print(f"[multi] {label} would run in instances/{label} "
                      f"(token {mask(tok)})")
                continue
            d = prepare(i, tok, cfg)
            env = dict(os.environ, TOKEN=tok, PYTHONUNBUFFERED="1",
                       WILT_INSTANCE=label)
            try:
                p = subprocess.Popen(
                    [sys.executable, str(APP / "selfbot.py")],
                    cwd=str(d), env=env,
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    text=True, encoding="utf-8", errors="replace",
                    bufsize=1)
            except Exception as e:
                print(f"[multi] {label} spawn failed: {e}")
                continue
            procs.append((label, p))
            print(f"[multi] {label} pid {p.pid} token {mask(tok)}")
            th = threading.Thread(target=relay, args=(label, p), daemon=True)
            th.start()
            threads.append(th)
        if dry:
            return 0

        def stop_all():
            for _, p in procs:
                if p.poll() is None:
                    try:
                        p.terminate()
                    except Exception:
                        pass

        def on_term(_sig, _frame):
            raise KeyboardInterrupt

        try:
            signal.signal(signal.SIGTERM, on_term)
        except Exception:
            pass
        for th in threads:
            th.join()
    except KeyboardInterrupt:
        stopped = True
        print("\n[multi] stopping instances...")
        for _, p in procs:
            if p.poll() is None:
                try:
                    p.terminate()
                except Exception:
                    pass
        for th in threads:
            th.join(10)
        for _, p in procs:
            if p.poll() is None:
                try:
                    p.kill()
                except Exception:
                    pass
    code = 0
    for label, p in procs:
        rc = p.wait()
        print(f"[multi] {label} exited ({rc})")
        if rc and not stopped and not code:
            code = rc
    return code


if __name__ == "__main__":
    sys.exit(main())
