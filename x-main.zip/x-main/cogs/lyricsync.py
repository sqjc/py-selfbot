# cogs/lyricsync.py | lyricsync
import re
import sys
import json
import time
import hmac
import hashlib
import base64
import asyncio
import urllib.parse
from datetime import datetime

import aiohttp
import modifyself_shim as discord
from . import state as S

TICK_MS = 100
POLL_MS = 1500
FAST_POLL_MS = 400
CHEAP_SOURCE_MS = 8
IDLE_POLL_MS = 5000
GRACE_MS = 8000
LYRIC_CACHE_TTL_S = 30 * 60
LYRIC_CACHE_MAX = 200
MAX_STATUS_LEN = 128
SEEK_BACK_SLACK_MS = 0
SEEK_REANCHOR_THRESHOLD_MS = 250
SEEK_BACK_MS = 2500
SEEK_FWD_MS = 8000
WRITE_COOLDOWN_S = 1.05
MAX_NETWORK_LEAD_MS = 1500
DEFAULT_LYRIC_EMOJI = "🎵"

LRCLIB_BASE = "https://lrclib.net"
LYRIC_UA = "LyricSyncEngine/1.0"
SETTINGS_URL = "https://discord.com/api/v9/users/@me/settings"

MXM_BASE = "https://www.musixmatch.com/ws/1.1/"
MXM_APP_ID = "web-desktop-app-v1.0"
MXM_UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36"
MXM_SEARCH_UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
MXM_SECRET_TTL_S = 4 * 3600

# Discord internal Spotify API
DISCORD_SPOTIFY_PATH = "https://discord.com/api/v9/users/@me/spotify/currently-playing"
DISCORD_SPOTIFY_POLL_MS = 1500    # fallback only; gateway presence is the primary signal
DISCORD_SPOTIFY_FRESH_MS = 15000  # treat result stale after 15 s

_MISSING = object()
_lyric_cache: dict = {}
_session = None
_next_write_allowed = 0.0
_ext_session = None
_mxm_secret = {"value": None, "at": 0.0}

# ── fallback source cache ──────────────────────────────────────────────────────
_discord_api_result: dict | None = None   # {"act": <activity-dict>, "at": float}


def _clean(t):
    return re.sub(r"\s+", " ", str("" if t is None else t)).strip()


_INSTRUMENTAL_PATTERN = re.compile(
    r"^[\s♪♫♬♩\(\[\{\-\.\,]*"
    r"(instrumental(\s+break)?|music|solo|guitar\s+solo|drum\s+solo|intro|outro|interlude)?"
    r"[\s♪♫♬♩\)\]\}\-\.\,]*$",
    re.IGNORECASE,
)

def _is_instrumental_text(text):
    if not text:
        return True
    t = str(text).strip()
    if not t:
        return True
    cleaned = re.sub(r"[♪♫♬♩\(\)\[\]\{\}\-\.\,]+", "", t).strip()
    if not cleaned:
        return True
    if _INSTRUMENTAL_PATTERN.fullmatch(t):
        return True
    return False

def _clean_lyric_text(text):
    if not text or _is_instrumental_text(text):
        return ""
    t = re.sub(r"[♪♫♬♩]", "", str(text)).strip()
    return _clean(t)


def _normalize_lyric_emoji(value):
    emoji = str(value or "").strip()
    if not emoji or emoji.lower() in ("none", "off", "clear", "-"):
        return ""
    if emoji.startswith(("<:", "<a:")) and not re.fullmatch(
            r"<a?:[A-Za-z0-9_]{2,32}:\d{1,20}>", emoji):
        return DEFAULT_LYRIC_EMOJI
    return emoji[:64]


def _status_emoji_fields(emoji):
    if not emoji:
        return None, None
    value = _normalize_lyric_emoji(emoji)
    if not value:
        return None, None
    match = re.fullmatch(r"<a?:([A-Za-z0-9_]{2,32}):(\d{1,20})>", value)
    if match:
        return match.group(1), match.group(2)
    return value, None


def _normalize_lines(raw):
    if not isinstance(raw, list):
        return []
    out = []
    for item in raw:
        if not item:
            continue
        if isinstance(item, (list, tuple)):
            if len(item) < 2:
                continue
            try:
                ms = float(item[0]) or 0
            except (TypeError, ValueError):
                ms = 0
            out.append({"timeMs": int(ms), "text": _clean_lyric_text(item[1])})
        elif isinstance(item, dict):
            v = item.get("timeMs") if item.get("timeMs") is not None else item.get("time")
            try:
                ms = float(v)
            except (TypeError, ValueError):
                continue
            if ms != ms:
                continue
            out.append({"timeMs": int(ms), "text": _clean_lyric_text(item.get("text"))})
    out.sort(key=lambda x: x["timeMs"])
    return out


def parse_lrc(lrc):
    if not lrc or not isinstance(lrc, str):
        return []
    out = []
    pat = re.compile(r"^\[(\d{1,2}):(\d{2})(?:\.(\d{0,3}))?\]\s*(.*)$")
    for line in re.split(r"\r?\n", lrc):
        m = pat.match(line)
        if not m:
            continue
        frac = (m.group(3) or "0").ljust(3, "0")
        raw_text = re.sub(r"\[[^\]]*\]", "", m.group(4))
        raw_text = re.sub(r"\s+", " ", raw_text).strip()
        cleaned_text = _clean_lyric_text(raw_text)
        time_ms = int(m.group(1)) * 60000 + int(m.group(2)) * 1000 + int(frac)
        out.append({"timeMs": time_ms, "text": cleaned_text})
    out.sort(key=lambda x: x["timeMs"])
    return out


def get_current_line(lines, position_ms, offset_ms=0):
    if not isinstance(lines, list) or not lines:
        return None
    pos = max(0, (position_ms or 0) + (offset_ms or 0))
    idx = -1
    for i, l in enumerate(lines):
        if l["timeMs"] <= pos:
            idx = i
        else:
            break
    if idx < 0:
        return None
    return {"line": lines[idx], "index": idx}


def get_next_line_delay(lines, position_ms, offset_ms=0):
    if not isinstance(lines, list) or not lines:
        return None
    pos = max(0, (position_ms or 0) + (offset_ms or 0))
    for l in lines:
        if l["timeMs"] > pos:
            return max(0, l["timeMs"] - pos)
    return None


def _duration_ms(act):
    if not act:
        return 0
    try:
        if float(act.get("durationMs") or 0) > 0:
            return int(float(act["durationMs"]))
    except (TypeError, ValueError):
        pass
    ts = act.get("timestamps") or {}
    try:
        s = float(ts.get("start") or 0)
        e = float(ts.get("end") or 0)
    except (TypeError, ValueError):
        return 0
    if s and e and e > s:
        return int(e - s)
    return 0


def _track_id(act):
    if not act:
        return None
    tid = act.get("syncId") or act.get("sync_id") or act.get("trackId")
    if tid:
        return str(tid)
    parts = [_clean(act.get("details") or act.get("title")),
             _clean(act.get("state") or act.get("artist"))]
    dur = _duration_ms(act)
    if dur:
        parts.append(str(dur))
    parts = [p for p in parts if p]
    return "|".join(parts)


def _same_track(a, b):
    if not a or not b:
        return False
    a_id = a.get("syncId") or a.get("sync_id") or a.get("trackId")
    b_id = b.get("syncId") or b.get("sync_id") or b.get("trackId")
    if a_id and b_id:
        return str(a_id) == str(b_id)
    at = _clean(a.get("details") or a.get("title")).lower()
    bt = _clean(b.get("details") or b.get("title")).lower()
    aa = _clean(a.get("state") or a.get("artist")).lower()
    ba = _clean(b.get("state") or b.get("artist")).lower()
    if not at or not bt or not aa or not ba:
        return False
    if at != bt or aa != ba:
        return False
    ad, bd = _duration_ms(a), _duration_ms(b)
    if ad > 0 and bd > 0 and abs(ad - bd) > 5000:
        return False
    return True


def _lyric_key(title, artist, duration_ms):
    dur = int(round((duration_ms or 0) / 1000))
    return "|".join([_clean(title).lower(), _clean(artist).lower(),
                     str(dur) if dur > 0 else ""])


def _cache_get(key):
    e = _lyric_cache.get(key)
    if e is None:
        return _MISSING
    if time.time() - e["at"] > LYRIC_CACHE_TTL_S:
        _lyric_cache.pop(key, None)
        return _MISSING
    _lyric_cache.pop(key, None)
    _lyric_cache[key] = e
    return e["data"]


def _cache_set(key, data):
    if not key:
        return
    _lyric_cache.pop(key, None)
    _lyric_cache[key] = {"data": data if data else None, "at": time.time()}
    while len(_lyric_cache) > LYRIC_CACHE_MAX:
        _lyric_cache.pop(next(iter(_lyric_cache)))


def _ext():
    global _ext_session
    if _ext_session is None or _ext_session.closed:
        _ext_session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=12))
    return _ext_session


async def _http_json(url, headers=None):
    try:
        async with _ext().get(url, headers=headers or {}) as r:
            text = await r.text()
            try:
                data = json.loads(text)
            except Exception:
                data = text
            return {"status": r.status, "data": data, "error": None}
    except Exception as e:
        return {"status": 0, "data": None, "error": str(e)}


async def fetch_lyrics(title, artist, album="", duration_ms=0, use_plain=False):
    """Fetch synchronized lyrics from https://lrclib.net/ with multiple matching strategies."""
    dur_sec = int(round((duration_ms or 0) / 1000)) if duration_ms else 0
    t = _clean(title)
    a = _clean(artist)
    if not t or not a:
        return None

    # Strategy 1: exact match with duration
    try:
        params = {"track_name": t, "artist_name": a}
        if dur_sec > 0:
            params["duration"] = str(dur_sec)
        if album:
            params["album_name"] = _clean(album)
        r = await _http_json(f"{LRCLIB_BASE}/api/get?{urllib.parse.urlencode(params)}",
                             {"User-Agent": LYRIC_UA})
        if r.get("status") == 200 and isinstance(r.get("data"), dict):
            if r["data"].get("syncedLyrics"):
                return {"synced": True, "lines": parse_lrc(r["data"]["syncedLyrics"])}
            if use_plain and r["data"].get("plainLyrics"):
                return {"synced": False, "text": r["data"]["plainLyrics"]}
    except Exception:
        pass

    # Strategy 2: exact match without duration or album constraint
    try:
        params = {"track_name": t, "artist_name": a}
        r = await _http_json(f"{LRCLIB_BASE}/api/get?{urllib.parse.urlencode(params)}",
                             {"User-Agent": LYRIC_UA})
        if r.get("status") == 200 and isinstance(r.get("data"), dict):
            if r["data"].get("syncedLyrics"):
                return {"synced": True, "lines": parse_lrc(r["data"]["syncedLyrics"])}
            if use_plain and r["data"].get("plainLyrics"):
                return {"synced": False, "text": r["data"]["plainLyrics"]}
    except Exception:
        pass

    # Strategy 3: structured search on lrclib.net
    try:
        params = {"track_name": t, "artist_name": a}
        r = await _http_json(f"{LRCLIB_BASE}/api/search?{urllib.parse.urlencode(params)}",
                             {"User-Agent": LYRIC_UA})
        if isinstance(r.get("data"), list) and r["data"]:
            best = next((x for x in r["data"] if isinstance(x, dict) and x.get("syncedLyrics")), None)
            if best is None and use_plain:
                best = next((x for x in r["data"] if isinstance(x, dict) and x.get("plainLyrics")), None)
            if best is not None:
                if best.get("syncedLyrics"):
                    return {"synced": True, "lines": parse_lrc(best["syncedLyrics"])}
                if use_plain and best.get("plainLyrics"):
                    return {"synced": False, "text": best["plainLyrics"]}
    except Exception:
        pass

    # Strategy 4: general query search on lrclib.net
    try:
        q = urllib.parse.quote(f"{t} {a}")
        r = await _http_json(f"{LRCLIB_BASE}/api/search?q={q}", {"User-Agent": LYRIC_UA})
        if isinstance(r.get("data"), list) and r["data"]:
            best = next((x for x in r["data"] if isinstance(x, dict) and x.get("syncedLyrics")), None)
            if best is None and use_plain:
                best = next((x for x in r["data"] if isinstance(x, dict) and x.get("plainLyrics")), None)
            if best is not None:
                if best.get("syncedLyrics"):
                    return {"synced": True, "lines": parse_lrc(best["syncedLyrics"])}
                if use_plain and best.get("plainLyrics"):
                    return {"synced": False, "text": best["plainLyrics"]}
    except Exception:
        pass

    # Strategy 5: cleaned title search (stripping feat, remasters, parens)
    clean_t = re.sub(r"\s*[\(\[\{].*?[\)\]\}]", "", t).strip()
    clean_a = re.split(r"[,&/]", a)[0].strip()
    if (clean_t and clean_t.lower() != t.lower()) or (clean_a and clean_a.lower() != a.lower()):
        try:
            q = urllib.parse.quote(f"{clean_t or t} {clean_a or a}")
            r = await _http_json(f"{LRCLIB_BASE}/api/search?q={q}", {"User-Agent": LYRIC_UA})
            if isinstance(r.get("data"), list) and r["data"]:
                best = next((x for x in r["data"] if isinstance(x, dict) and x.get("syncedLyrics")), None)
                if best is not None and best.get("syncedLyrics"):
                    return {"synced": True, "lines": parse_lrc(best["syncedLyrics"])}
        except Exception:
            pass

    return None


def _py_quote(s):
    return urllib.parse.quote(s, safe="/")


async def _mxm_get_secret():
    now = time.time()
    if _mxm_secret["value"] and now - _mxm_secret["at"] < MXM_SECRET_TTL_S:
        return _mxm_secret["value"]
    async with _ext().get("https://www.musixmatch.com/search",
                          headers={"user-agent": MXM_SEARCH_UA, "Cookie": "mxm_bab=AB"}) as r:
        search_html = await r.text()
    app_matches = re.findall(r'src="([^"]*/_next/static/chunks/pages/_app-[^"]+\.js)"', search_html)
    if not app_matches:
        raise RuntimeError("mxm: _app chunk not found")
    app_url = app_matches[-1]
    if app_url.startswith("/"):
        app_url = "https://www.musixmatch.com" + app_url
    async with _ext().get(app_url, headers={"user-agent": MXM_UA}) as r:
        app_js = await r.text()
    m = re.search(r'from\(\s*"(.*?)"\s*\.split', app_js)
    if not m:
        raise RuntimeError("mxm: signing secret not found")
    reversed_b64 = m.group(1)[::-1]
    decoded = base64.b64decode(reversed_b64).decode("utf-8", "replace")
    _mxm_secret["value"] = decoded
    _mxm_secret["at"] = now
    return decoded


async def _mxm_sign(endpoint_path):
    secret = await _mxm_get_secret()
    msg = endpoint_path + datetime.now().strftime("%Y%m%d")
    sig = base64.b64encode(
        hmac.new(secret.encode("utf-8"), msg.encode("utf-8"), hashlib.sha256).digest()
    ).decode("ascii")
    return "&signature=" + _py_quote(sig) + "&signature_protocol=sha256"


async def _mxm_request(endpoint):
    path = endpoint.replace("%20", "+").replace(" ", "+")
    sig = await _mxm_sign(path)
    url = MXM_BASE + path + sig
    async with _ext().get(url, headers={"user-agent": MXM_UA}) as r:
        text = await r.text()
    return json.loads(text)


def _mxm_normalize_query(title, artist):
    t = _clean(title)
    a = _clean(re.split(r"[,&]", _clean(artist))[0])
    return f"{t} {a}".strip()


def _mxm_parse_richsync_body(raw):
    if not raw:
        return None
    try:
        arr = json.loads(raw) if isinstance(raw, str) else raw
    except Exception:
        return None
    if not isinstance(arr, list) or not arr:
        return None
    lines = []
    for entry in arr:
        if not isinstance(entry, dict):
            continue
        start_raw = entry.get("#start")
        if start_raw is None:
            continue
        try:
            start_ms = int(round(float(start_raw) * 1000))
        except (TypeError, ValueError):
            continue
        text = str(entry.get("#text") or "").strip()
        if not text:
            continue
        for sub in re.split(r"\n", text):
            piece = sub.strip()
            if piece:
                lines.append({"timeMs": start_ms, "text": piece})
    if not lines:
        return None
    lines.sort(key=lambda x: x["timeMs"])
    return lines


def _mxm_strip_lyrics_body(body):
    if not body:
        return None
    return re.sub(r"\([0-9]+\.\.[0-9]+\)\s*$", "", str(body)).strip()


async def fetch_musixmatch_lyrics(title, artist):
    q = _mxm_normalize_query(title, artist)
    if not q:
        return None
    try:
        search = await _mxm_request(
            f"track.search?app_id={MXM_APP_ID}&format=json&q={urllib.parse.quote(q)}"
            f"&f_has_lyrics=true&page_size=10&page=1")
    except Exception:
        return None
    try:
        track_list = search["message"]["body"]["track_list"]
    except (KeyError, TypeError):
        track_list = None
    if not isinstance(track_list, list) or not track_list:
        return None
    try:
        track_id = track_list[0]["track"]["track_id"]
    except (KeyError, TypeError, IndexError):
        track_id = None
    if not track_id:
        return None
    try:
        rich = await _mxm_request(
            f"track.richsync.get?app_id={MXM_APP_ID}&format=json&track_id={track_id}")
    except Exception:
        rich = None
    try:
        raw_body = rich["message"]["body"]["richsync"]["richsync_body"]
    except (KeyError, TypeError):
        raw_body = None
    rich_lines = _mxm_parse_richsync_body(raw_body)
    if rich_lines:
        return {"synced": True, "lines": rich_lines}
    try:
        plain = await _mxm_request(
            f"track.lyrics.get?app_id={MXM_APP_ID}&format=json&track_id={track_id}")
    except Exception:
        plain = None
    try:
        lyrics = plain["message"]["body"]["lyrics"]
    except (KeyError, TypeError):
        lyrics = None
    body = _mxm_strip_lyrics_body((lyrics or {}).get("lyrics_body"))
    if not body:
        return None
    if re.match(r"^\s*instrumental\s*$", body, re.IGNORECASE):
        return {"synced": False, "instrumental": True}
    return {"synced": False, "text": body}


class _Session:
    def __init__(self, cfg):
        self.cfg = cfg
        configured_emoji = cfg.get("emoji")
        self.lyric_emoji = (
            _normalize_lyric_emoji(configured_emoji)
            if configured_emoji else ""
        )
        self.offset_ms = int(cfg.get("offset_ms") or 0)
        self.gap_ms = int(cfg.get("gap_ms") or 4000)
        self.plain_fallback = False
        self.alive = False
        self.is_paused = False
        self._act = None
        self._act_at = 0.0
        self._empty_since = 0.0
        self._last_good_at = 0.0
        self.idle = True
        self._src_cost = 0.0
        self._last_src = "none"        # which source last provided activity
        self.current_sync = None
        self.fetch_key = None
        self.lyrics = None
        self.fetching = False
        self.last_pushed = None
        self.last_text = ""
        self.last_emoji = ""
        self.last_lyric_line = ""
        self.last_lyric_at = 0
        self._freeze_pos = 0.0
        self.push_inflight = False
        self.status_rtt_ms = None
        self.poll_task = None
        self.render_task = None
        self.fetch_task = None
        self.push_task = None
        self.track_generation = 0
        self.presence_callback = None
        self.api_poll_task = None      # Discord Spotify API background poller


def _effective_offset(session):
    # Pure millisecond offset from user configuration for exact, line-by-line sync
    return session.offset_ms


def _clear_held_line(session):
    session.last_lyric_line = ""
    session.last_lyric_at = 0


def _reset_playback(session):
    session.track_generation += 1
    session._act = None
    session._act_at = 0.0
    session._empty_since = 0.0
    session.current_sync = None
    session.fetch_key = None
    session.fetching = False
    session.lyrics = None
    session._freeze_pos = 0.0
    session.is_paused = False
    _clear_held_line(session)


def _apply_lyric_data(session, data, duration_ms):
    if not data:
        session.lyrics = []
    elif data.get("synced"):
        lines = data.get("lines") or []
        has_words = any(l.get("text") for l in lines if isinstance(l, dict))
        session.lyrics = lines if has_words else []
    else:
        # Untimed lyrics cannot be aligned to playback without inventing timing.
        session.lyrics = []


async def _fetch_for_session(session, title, artist, album, duration_ms,
                             cache_key, generation):
    try:
        data = await fetch_lyrics(title, artist, album or "", duration_ms or 0,
                                  use_plain=False)
        _cache_set(cache_key, data or None)
        if session.track_generation != generation:
            return
        _apply_lyric_data(session, data, duration_ms)
        if session.alive and session._act:
            _render_once(session)
    except Exception:
        if session.track_generation == generation:
            session.lyrics = []
            if session.alive and session._act:
                _render_once(session)
    finally:
        if session.track_generation == generation:
            session.fetching = False


def _on_song_change(session, act):
    if session.fetch_task and not session.fetch_task.done():
        session.fetch_task.cancel()
    session.track_generation += 1
    generation = session.track_generation
    session._act = act
    session._act_at = time.time()
    session.is_paused = False
    session.idle = False
    session._empty_since = 0.0
    session._last_good_at = time.time()
    session.last_pushed = None
    _clear_held_line(session)
    session._freeze_pos = _calc_pos(act)

    title = _clean(act.get("details") or act.get("title"))
    artist = _clean(act.get("state") or act.get("artist"))
    assets = act.get("assets") or {}
    album = _clean(act.get("album") or assets.get("large_text") or "")
    duration_ms = _duration_ms(act)
    tid = _track_id(act)
    session.current_sync = tid
    session.fetch_key = tid

    cache_key = _lyric_key(title, artist, duration_ms)
    cached = _cache_get(cache_key)
    if cached is not _MISSING:
        _apply_lyric_data(session, cached, duration_ms)
        session.fetching = False
        _render_once(session)
        return

    session.lyrics = None
    session.fetching = True
    session.fetch_task = asyncio.create_task(
        _fetch_for_session(session, title, artist, album, duration_ms, cache_key,
                           generation))


def _calc_pos(act):
    if not act:
        return 0.0
    now_ms = time.time() * 1000.0
    ts = act.get("timestamps") or {}
    try:
        start = float(ts.get("start") or 0)
    except (TypeError, ValueError):
        start = 0
    if start > 0:
        pos = max(0.0, now_ms - start)
        dur = _duration_ms(act)
        if dur > 0 and pos > dur:
            pos = dur
        return pos
    pos_field = act.get("positionMs")
    if isinstance(pos_field, (int, float)):
        return max(0.0, float(pos_field))
    return 0.0


def _playback_position(session):
    act = session._act
    if not act:
        return (0.0, False)
    if session.is_paused:
        return (session._freeze_pos, True)
    now_ms = time.time() * 1000.0
    ts = act.get("timestamps") or {}
    try:
        start = float(ts.get("start") or 0)
    except (TypeError, ValueError):
        start = 0
    if start > 0:
        dur = _duration_ms(act)
        pos = max(0.0, now_ms - start)
        if dur > 0 and pos > dur:
            pos = dur
        session._freeze_pos = pos
        return (pos, False)
    pos_field = act.get("positionMs")
    if isinstance(pos_field, (int, float)):
        is_playing = act.get("isPlaying", True)
        if not is_playing:
            return (session._freeze_pos or float(pos_field), True)
        at = (session._act_at * 1000.0) or now_ms
        elapsed = max(0.0, now_ms - at)
        pos = float(pos_field) + elapsed
        dur = _duration_ms(act)
        if dur > 0 and pos > dur:
            pos = dur
        session._freeze_pos = pos
        return (pos, False)
    return (session._freeze_pos, True)


def _on_seek(session, pos):
    session.last_pushed = None
    session.last_lyric_line = ""
    session.last_lyric_at = 0
    session._freeze_pos = max(0.0, float(pos or 0))
    if session.lyrics:
        anchor_pos = max(0.0, float(pos or 0))
        try:
            anchor_pos = max(0.0, float(pos or 0) + _effective_offset(session))
        except Exception:
            pass
        anchor = get_current_line(session.lyrics, anchor_pos)
        if anchor and anchor["line"]["text"]:
            session.last_lyric_line = anchor["line"]["text"]
            session.last_lyric_at = anchor["line"]["timeMs"]
        else:
            prev = None
            for l in session.lyrics:
                if l["timeMs"] > anchor_pos:
                    break
                if l["text"]:
                    prev = l
            if prev:
                session.last_lyric_line = prev["text"]
                session.last_lyric_at = prev["timeMs"]



# ── fallback source: Discord Profile / Currently-Playing endpoint ────────────
async def _poll_discord_spotify_api():
    """Fetch currently-playing or profile activities from Discord API.

    Returns an activity-dict on success, None when Spotify is not playing.
    """
    global _discord_api_result
    try:
        headers = {
            "Authorization": S.TOKEN,
            "User-Agent": S.USER_AGENT or LYRIC_UA,
            "Accept": "application/json",
        }
        client = getattr(S, "CLIENT", None) or getattr(S, "MAIN_CLIENT", None)
        user_id = str(getattr(getattr(client, "user", None), "id", "") or "").strip()

        # 1. Try currently-playing endpoint
        r = await _http_json(DISCORD_SPOTIFY_PATH, headers)
        if r.get("status") == 200 and isinstance(r.get("data"), dict):
            data = r["data"]
            item = data.get("item") or {}
            if item:
                artists = item.get("artists") or []
                artist = ", ".join(a.get("name", "") for a in artists if a.get("name")) or "Unknown"
                album_obj = item.get("album") or {}
                album = album_obj.get("name", "")
                assets = {}
                images = album_obj.get("images") or []
                if images:
                    assets["large_image"] = images[0].get("url", "")
                    assets["large_text"] = album
                duration_ms = int(item.get("duration_ms") or 0)
                progress_ms = int(data.get("progress_ms") or 0)
                is_playing = bool(data.get("is_playing", False))
                now_ms = time.time() * 1000.0
                act = {
                    "type": 2,
                    "name": "Spotify",
                    "details": _clean(item.get("name") or ""),
                    "state": _clean(artist),
                    "album": _clean(album),
                    "assets": assets,
                    "sync_id": item.get("id") or "",
                    "durationMs": duration_ms,
                    "positionMs": progress_ms,
                    "isPlaying": is_playing,
                    "timestamps": {
                        "start": int(now_ms - progress_ms) if is_playing else None,
                        "end": int(now_ms - progress_ms + duration_ms) if is_playing else None,
                    },
                }
                _discord_api_result = {"act": act, "at": time.time()}
                return act

        # 2. Try user profile activities endpoint
        profile_url = f"https://discord.com/api/v9/users/{user_id}/profile" if user_id else "https://discord.com/api/v9/users/@me/profile"
        r_prof = await _http_json(profile_url, headers)
        if r_prof.get("status") == 200 and isinstance(r_prof.get("data"), dict):
            prof_data = r_prof["data"]
            for a in prof_data.get("activities", []):
                if not isinstance(a, dict):
                    continue
                if a.get("type") == 2 or str(a.get("name", "")).lower() == "spotify":
                    dur_ms = 0
                    ts = a.get("timestamps") or {}
                    start = float(ts.get("start") or 0)
                    end = float(ts.get("end") or 0)
                    if start > 0 and end > start:
                        dur_ms = int(end - start)
                    act = {
                        "type": 2,
                        "name": "Spotify",
                        "details": _clean(a.get("details") or a.get("name") or ""),
                        "state": _clean(a.get("state") or ""),
                        "album": _clean(a.get("assets", {}).get("large_text") or ""),
                        "assets": a.get("assets") or {},
                        "sync_id": a.get("sync_id") or "",
                        "durationMs": dur_ms,
                        "isPlaying": True,
                        "timestamps": ts,
                    }
                    _discord_api_result = {"act": act, "at": time.time()}
                    return act
    except Exception:
        pass
    return None


def _get_discord_api_act():
    """Return the cached Discord-API result if it is still fresh."""
    r = _discord_api_result
    if not r:
        return None
    if time.time() - r["at"] > DISCORD_SPOTIFY_FRESH_MS / 1000.0:
        return None
    return r["act"]


def _get_best_spotify_activity():
    """Return the freshest available Spotify activity from all sources.

    Priority:
      1. Gateway presence (PRESENCE_UPDATE, SESSIONS_REPLACE, READY — zero latency)
      2. Bot RPC presence (.spotify command, active listening slot)
      3. Discord API (currently playing / profile activities fallback)
    """
    # Source 1: gateway presence
    gw = S.get_spotify_activity()
    if gw and _clean(gw.get("details") or gw.get("title")):
        return gw, "presence"

    # Source 2: bot RPC
    rpc_act = S.get_rpc_spotify_activity()
    if rpc_act and _clean(rpc_act.get("details") or rpc_act.get("title")):
        return rpc_act, "rpc"

    # Source 3: Discord API
    api = _get_discord_api_act()
    if api and _clean(api.get("details")):
        return api, "discord-api"

    return None, "none"


def _handle_spotify_update(session, act, src):
    if not session or not session.alive:
        return
    now = time.time()
    session._last_src = src

    if not act or not _clean(act.get("details") or act.get("title")):
        if session._act and not session.is_paused:
            session.is_paused = True
            try:
                session._freeze_pos = _playback_position(session)[0]
            except Exception:
                pass
            session._empty_since = now
        elif session.is_paused:
            if session._empty_since and (now - session._empty_since > 60.0):
                _reset_playback(session)
                session.idle = True
                _render_once(session)
        return

    is_playing = act.get("isPlaying")
    if is_playing is False:
        if session._act and _same_track(session._act, act):
            session.is_paused = True
            pos_field = act.get("positionMs")
            if pos_field is not None:
                session._freeze_pos = float(pos_field)
            session._act = act
            session._act_at = now
            return
        else:
            _on_song_change(session, act)
            session.is_paused = True
            pos_field = act.get("positionMs")
            if pos_field is not None:
                session._freeze_pos = float(pos_field)
            return

    was_paused = session.is_paused
    session.is_paused = False
    session.idle = False
    session._empty_since = 0.0
    session._last_good_at = now

    if session._act is None or not _same_track(session._act, act):
        _on_song_change(session, act)
        return

    try:
        old_pos = _playback_position(session)[0]
    except Exception:
        old_pos = None

    session._act = act
    session._act_at = now
    new_pos = _calc_pos(act)
    session._freeze_pos = new_pos

    if was_paused or (
            old_pos is not None
            and abs(new_pos - old_pos) > SEEK_REANCHOR_THRESHOLD_MS):
        _on_seek(session, new_pos)
        _render_once(session)


async def _probe_spotify_immediately():
    gw = S.get_spotify_activity()
    if gw and _clean(gw.get("details") or gw.get("title")):
        return gw, "presence"
    rpc_act = S.get_rpc_spotify_activity()
    if rpc_act and _clean(rpc_act.get("details") or rpc_act.get("title")):
        return rpc_act, "rpc"
    try:
        api = await _poll_discord_spotify_api()
        if api and _clean(api.get("details")):
            return api, "discord-api"
    except Exception:
        pass
    return None, "none"


async def _poll_once(session):
    if not session.alive:
        return
    t0 = time.time()
    act, _src = _get_best_spotify_activity()
    cost = (time.time() - t0) * 1000.0
    session._src_cost = max(cost, session._src_cost * 0.5)
    _handle_spotify_update(session, act, _src)


async def _poll_loop(session):
    while session.alive:
        try:
            await _poll_once(session)
        except asyncio.CancelledError:
            return
        except Exception:
            pass
        if not session.alive:
            return
        delay = 1000 if session.idle else FAST_POLL_MS
        try:
            await asyncio.sleep(delay / 1000.0)
        except asyncio.CancelledError:
            return


async def _api_poll_loop(session):
    try:
        act = await _poll_discord_spotify_api()
        if act and _session is session:
            _handle_spotify_update(session, act, "discord-api")
    except Exception:
        pass
    while session.alive:
        try:
            await asyncio.sleep(DISCORD_SPOTIFY_POLL_MS / 1000.0)
        except asyncio.CancelledError:
            return
        if not session.alive:
            return
        try:
            act = await _poll_discord_spotify_api()
            if act and _session is session:
                _handle_spotify_update(session, act, "discord-api")
        except asyncio.CancelledError:
            return
        except Exception:
            pass


def _render_once(session):
    status_text = None
    status_emoji = ""
    clear_status = False
    skip_render = False
    try:
        act = session._act
        if not act or not _clean(act.get("details") or act.get("title")):
            clear_status = True
        else:
            status_emoji = session.lyric_emoji or ""
            pos = _playback_position(session)[0]
            look_pos = max(0.0, pos + _effective_offset(session))

            if session.lyrics:
                cur = get_current_line(session.lyrics, look_pos)
                if cur:
                    raw_text = cur["line"].get("text", "")
                    clean_text = _clean_lyric_text(raw_text)
                    if clean_text:
                        status_text = clean_text
                        session.last_lyric_line = clean_text
                        session.last_lyric_at = cur["line"]["timeMs"]
                    else:
                        # Instrumental break or gap
                        _clear_held_line(session)
                        status_text = ""
                else:
                    _clear_held_line(session)
                    status_text = ""

            if not status_text and session.last_lyric_line:
                gap_ms = look_pos - float(session.last_lyric_at or 0)
                if session.last_lyric_at and gap_ms <= session.gap_ms:
                    status_text = session.last_lyric_line
                else:
                    _clear_held_line(session)
                    status_text = ""
    except Exception:
        status_text = None
        status_emoji = ""

    if skip_render:
        return

    final_text = "" if clear_status else (
        str(status_text)[:MAX_STATUS_LEN] if status_text else "")
    final_emoji = "" if clear_status else (status_emoji or "")

    if final_emoji and final_text:
        composite = f"{final_emoji} {final_text}"
    else:
        composite = final_text or final_emoji

    if composite != session.last_pushed:
        _try_push(session, final_text, final_emoji, composite)


async def _render_loop(session):
    while session.alive:
        try:
            _render_once(session)
        except asyncio.CancelledError:
            return
        except Exception:
            pass
        try:
            await asyncio.sleep(TICK_MS / 1000.0)
        except asyncio.CancelledError:
            return


def _try_push(session, text, emoji, composite):
    global _next_write_allowed
    if session.push_inflight:
        return
    if time.time() < _next_write_allowed:
        return
    session.push_inflight = True
    session.last_text = text
    session.last_emoji = emoji
    session.push_task = asyncio.create_task(_do_push(session, text, emoji, composite))


async def _push_custom_status(text, emoji):
    emoji_name, emoji_id = _status_emoji_fields(emoji)
    headers = {"Authorization": S.TOKEN, "Content-Type": "application/json",
               "User-Agent": S.USER_AGENT}
    payload = {"custom_status": {"text": (text or "")[:MAX_STATUS_LEN],
                                 "emoji_name": emoji_name,
                                 "emoji_id": emoji_id}}
    sess = S._get_session()
    async with sess.patch(SETTINGS_URL, headers=headers, json=payload,
                          timeout=aiohttp.ClientTimeout(total=8)) as r:
        retry_after = 0.0
        if r.status == 429:
            try:
                body = await r.json(content_type=None)
                retry_after = float(body.get("retry_after") or 1.0)
            except Exception:
                retry_after = 1.0
        else:
            try:
                await r.read()
            except Exception:
                pass
        return r.status, retry_after


_last_fail_print = 0.0


async def _do_push(session, text, emoji, composite):
    global _next_write_allowed, _last_fail_print
    try:
        if not session.alive:
            return
        request_started = time.time()
        status, retry_after = await _push_custom_status(text, emoji)
        rtt_ms = max(0.0, (time.time() - request_started) * 1000.0)
        if session.status_rtt_ms is None:
            session.status_rtt_ms = rtt_ms
        else:
            # React quickly to a worsening route while smoothing transient spikes.
            weight = 0.6 if rtt_ms > session.status_rtt_ms else 0.2
            session.status_rtt_ms = min(
                MAX_NETWORK_LEAD_MS * 2,
                session.status_rtt_ms * (1.0 - weight) + rtt_ms * weight,
            )
        if status in (200, 204):
            # Space request starts, not response completions. Otherwise a high
            # RTT adds itself on top of the server's per-update cooldown.
            _next_write_allowed = max(
                request_started + WRITE_COOLDOWN_S, time.time())
            session.last_pushed = composite
        elif status == 429:
            _next_write_allowed = time.time() + max(0.5, retry_after)
        else:
            now = time.time()
            if now - _last_fail_print > 60:
                _last_fail_print = now
                print(f"[lyricsync] status push failed ({status})")
            _next_write_allowed = now + 5.0
    except Exception as e:
        now = time.time()
        if now - _last_fail_print > 60:
            _last_fail_print = now
            print(f"[lyricsync] status push error: {e}")
        _next_write_allowed = now + 3.0
    finally:
        session.push_inflight = False


def _load_cfg(*, default_emoji=True):
    try:
        cfg = S.load_config() or {}
    except Exception:
        cfg = {}
    d = cfg.get("lyric_sync") if isinstance(cfg.get("lyric_sync"), dict) else {}
    try:
        offset = int(d.get("offset_ms") or 0)
    except (TypeError, ValueError):
        offset = 0
    configured_emoji = d.get("emoji")
    emoji = (
        _normalize_lyric_emoji(configured_emoji)
        if configured_emoji or default_emoji else ""
    )
    try:
        gap = int(d.get("gap_ms") or 4000)
    except (TypeError, ValueError):
        gap = 4000
    plain = d.get("plain_fallback")
    return {"enabled": bool(d.get("enabled")), "offset_ms": offset, "emoji": emoji,
            "gap_ms": gap, "plain_fallback": True if plain is None else bool(plain)}


def _save_cfg(cfg):
    try:
        full = S.load_config() or {}
    except Exception:
        full = {}
    full["lyric_sync"] = cfg
    S.save_config(full)


def _sync_ipc(flag):
    try:
        main = sys.modules.get("__main__")
        mods = getattr(main, "_modules", None)
        if isinstance(mods, dict):
            mods["lyrics"] = bool(flag)
    except Exception:
        pass


def start_sync(cfg=None):
    global _session
    if _session and _session.alive:
        return _session
    cfg = cfg or _load_cfg()
    session = _Session(cfg)
    session.alive = True
    _session = session

    def _presence_cb(sp):
        if _session is session and session.alive:
            best, src = _get_best_spotify_activity()
            _handle_spotify_update(session, best or sp, src if best else "presence")

    session.presence_callback = _presence_cb
    S.register_spotify_listener(_presence_cb)
    session.poll_task = asyncio.create_task(_poll_loop(session))
    session.render_task = asyncio.create_task(_render_loop(session))
    session.api_poll_task = asyncio.create_task(_api_poll_loop(session))
    print("[lyricsync] started (presence listener + bot-rpc + discord-api active, lrclib synced)")
    return session


async def stop_sync():
    global _session
    session = _session
    _session = None
    if not session:
        return False
    session.alive = False
    S.unregister_spotify_listener(session.presence_callback)
    tasks = (session.poll_task, session.render_task, session.fetch_task,
             session.push_task, session.api_poll_task)
    for task in tasks:
        if task is not None and not task.done():
            task.cancel()
    await asyncio.gather(
        *(task for task in tasks if task is not None),
        return_exceptions=True,
    )
    wait = min(max(0.0, _next_write_allowed - time.time()), 2.0)
    if wait > 0:
        await asyncio.sleep(wait)
    for attempt in range(3):
        try:
            status, retry_after = await _push_custom_status("", "")
            if status in (200, 204):
                break
            if status != 429 or attempt == 2:
                print(f"[lyricsync] status clear failed ({status})")
                break
            await asyncio.sleep(max(0.5, retry_after))
        except Exception as e:
            print(f"[lyricsync] status clear error: {e}")
            break
    return True


def is_active():
    return bool(_session and _session.alive)


async def autostart():
    cfg = _load_cfg(default_emoji=False)
    if cfg.get("enabled"):
        start_sync(cfg)
        _sync_ipc(True)
        print("[lyricsync] auto-started from config")


def _fmt_age(age):
    if age is None:
        return "never"
    if age < 2:
        return "just now"
    if age < 60:
        return f"{int(age)}s ago"
    return f"{int(age // 60)}m ago"


class LyricSyncCog:
    COMMANDS = {"lyricsync", "lyrics"}

    async def handle(self, message, cmd, args):
        sub = args[1].lower() if len(args) > 1 else ""
        if sub in ("", "status", "info"):
            await self._status(message)
        elif sub in ("on", "start"):
            await self._on(message)
        elif sub in ("off", "stop"):
            await self._off(message)
        elif sub == "now":
            await self._now(message)
        elif sub == "offset":
            await self._offset(message, args[2:])
        elif sub == "emoji":
            await self._emoji(message, args[2:])
        elif sub in ("diag", "debug"):
            await self._diag(message)
        elif sub in ("help", "h"):
            await self._help(message)
        else:
            await self._help(message)

    async def _help(self, message):
        rows = [
            f"  {S.RED}.lyrics on{S.RESET}             {S.DIM}start syncing lyrics to your status{S.RESET}",
            f"  {S.RED}.lyrics off{S.RESET}            {S.DIM}stop lyrics sync and clear status{S.RESET}",
            f"  {S.RED}.lyrics now{S.RESET}            {S.DIM}probe Spotify immediately & sync current song{S.RESET}",
            f"  {S.RED}.lyrics status{S.RESET}         {S.DIM}show current track, sync state, and source{S.RESET}",
            f"  {S.RED}.lyrics offset <ms>{S.RESET}    {S.DIM}adjust timing (+/- ms, e.g. +500 or -300){S.RESET}",
            f"  {S.RED}.lyrics emoji <emoji>{S.RESET}  {S.DIM}set status emoji (none resets to 🎵){S.RESET}",
            f"  {S.RED}.lyrics diag{S.RESET}           {S.DIM}show presence & fallback source diagnostics{S.RESET}",
            f"  {S.RED}.fetchlyrics <song>{S.RESET}    {S.DIM}search and view full lyrics for any song{S.RESET}",
        ]
        await message.edit(content=S.ui_box("lyrics help", rows))

    async def _on(self, message):
        cfg = _load_cfg()
        cfg["enabled"] = True
        _save_cfg(cfg)
        _sync_ipc(True)
        session = start_sync(cfg)

        # Immediate fast probe so lyrics appear instantly without waiting
        act, src = await _probe_spotify_immediately()
        if act and _clean(act.get("details") or act.get("title")):
            session._act = act
            session._act_at = time.time()
            session.idle = False
            session._last_src = src
            _handle_spotify_update(session, act, src)
            title = _clean(act.get("details") or act.get("title"))
            artist = _clean(act.get("state") or act.get("artist"))
            await message.edit(content=S.ui_ok(
                f"lyrics on — syncing: **{title}** — {artist} ({src})"))
        else:
            await message.edit(content=S.ui_ok(
                "lyrics on — waiting for Spotify playback"))

    async def _off(self, message):
        cfg = _load_cfg()
        cfg["enabled"] = False
        _save_cfg(cfg)
        stopped = await stop_sync()
        _sync_ipc(False)
        if stopped:
            await message.edit(content=S.ui_ok("lyrics sync off"))
        else:
            await message.edit(content=S.ui_ok("lyrics sync disabled (was not running)"))

    async def _now(self, message):
        """Fetch the current Spotify track and start syncing lyrics immediately."""
        await message.edit(content=S.ui_info("lyrics now — probing sources…"))
        act, src = await _probe_spotify_immediately()

        if not act or not _clean(act.get("details") or act.get("title")):
            return await message.edit(content=S.ui_err(
                "no spotify activity found — make sure Spotify is open and playing"))

        title  = _clean(act.get("details") or act.get("title"))
        artist = _clean(act.get("state")   or act.get("artist"))

        if not is_active():
            cfg = _load_cfg()
            cfg["enabled"] = True
            _save_cfg(cfg)
            start_sync(cfg)
            _sync_ipc(True)

        target_session = _session
        if target_session:
            _handle_spotify_update(target_session, act, src)
        generation = target_session.track_generation if target_session else None

        dur = _duration_ms(act)
        assets = act.get("assets") or {}
        album = _clean(act.get("album") or assets.get("large_text") or "")
        cache_key = _lyric_key(title, artist, dur)
        cached = _cache_get(cache_key)
        if cached is not _MISSING and cached and cached.get("lines"):
            n = len(cached["lines"])
            return await message.edit(content=S.ui_ok(
                f"syncing {n} lines | **{title}** — {artist} | src: {src}"))

        await message.edit(content=S.ui_info(
            f"found via {src}: **{title}** — {artist}\nfetching lyrics…"))
        try:
            if (target_session and target_session.fetching
                    and target_session.fetch_task is not None):
                await asyncio.shield(target_session.fetch_task)
                lines = target_session.lyrics or []
                data = {"synced": True, "lines": lines} if lines else None
            else:
                data = await fetch_lyrics(title, artist, album, dur, False)
                _cache_set(cache_key, data)
        except asyncio.CancelledError:
            data = None
        except Exception as e:
            data = None
            print(f"[lyrics now] fetch error: {e}")

        if (target_session is None or _session is not target_session
                or target_session.track_generation != generation
                or not _same_track(target_session._act, act)):
            await message.edit(content=S.ui_warn(
                "Spotify track changed while lyrics were loading; syncing the current track"))
            return

        if data and data.get("synced") and data.get("lines"):
            n = len(data["lines"])
            _apply_lyric_data(target_session, data, dur)
            _render_once(target_session)
            await message.edit(content=S.ui_ok(
                f"syncing {n} lines | **{title}** — {artist} | src: {src}"))
        else:
            await message.edit(content=S.ui_warn(
                f"no synced lyrics found for **{title}** — {artist} | engine still running"))

    async def _offset(self, message, rest):
        if not rest:
            cur = (_session.offset_ms if _session else _load_cfg()["offset_ms"])
            return await message.edit(content=S.ui_err(
                f"usage: lyricsync offset <ms>  (current: {cur:+d}ms)"))
        raw = rest[0]
        try:
            val = int(raw)
        except ValueError:
            return await message.edit(content=S.ui_err("offset must be an integer (ms)"))
        if raw.startswith("+") and _session:
            val = _session.offset_ms + val
        elif raw.startswith("+"):
            val = _load_cfg()["offset_ms"] + val
        val = max(-15000, min(15000, val))
        cfg = _load_cfg()
        cfg["offset_ms"] = val
        _save_cfg(cfg)
        if _session:
            _session.offset_ms = val
        await message.edit(content=S.ui_ok(f"offset set to {val:+d}ms"))

    async def _emoji(self, message, rest):
        if not rest:
            cur = (_session.lyric_emoji if _session else _load_cfg()["emoji"])
            return await message.edit(content=S.ui_err(
                f"usage: lyricsync emoji <emoji|none>  (current: {cur or '(none)'})"))
        raw = rest[0]
        if raw.startswith(("<:", "<a:")) and not re.fullmatch(
                r"<a?:[A-Za-z0-9_]{2,32}:\d{1,20}>", raw):
            return await message.edit(content=S.ui_err(
                "custom emoji must use the full format <:name:id> or <a:name:id>"))
        val = _normalize_lyric_emoji(raw)
        cfg = _load_cfg()
        cfg["emoji"] = val
        _save_cfg(cfg)
        if _session:
            _session.lyric_emoji = val
        await message.edit(content=S.ui_ok(f"emoji set to {val}"))

    async def _diag(self, message):
        """Show diagnostic information for all Spotify sources."""
        rows = []

        # Gateway presence
        gw = S.get_spotify_activity()
        gw_age = S.own_presence_age()
        if gw and _clean(gw.get("details") or gw.get("title")):
            rows.append(f"  {S.DIM}presence:{S.RESET} {S.GREEN}✓{S.RESET} "
                        f"{_clean(gw.get('details'))} ({_fmt_age(gw_age)})")
        else:
            rows.append(f"  {S.DIM}presence:{S.RESET} {S.YELLOW}—{S.RESET} "
                        f"no activity ({_fmt_age(gw_age)})")

        # Bot RPC / .spotify presence
        rpc_act = S.get_rpc_spotify_activity()
        if rpc_act and _clean(rpc_act.get("details") or rpc_act.get("title")):
            rows.append(f"  {S.DIM}rpc:{S.RESET} {S.GREEN}✓{S.RESET} "
                        f"{_clean(rpc_act.get('details') or rpc_act.get('title'))}")
        else:
            rows.append(f"  {S.DIM}rpc:{S.RESET} {S.YELLOW}—{S.RESET} no rpc activity")

        # Discord Spotify API
        api_r = _discord_api_result
        if api_r:
            age_s = time.time() - api_r["at"]
            act = api_r["act"]
            fresh = age_s <= DISCORD_SPOTIFY_FRESH_MS / 1000.0
            sym = S.GREEN + "✓" + S.RESET if fresh else S.YELLOW + "stale" + S.RESET
            rows.append(f"  {S.DIM}discord-api:{S.RESET} {sym} "
                        f"{_clean(act.get('details'))} ({int(age_s)}s ago)")
        else:
            rows.append(f"  {S.DIM}discord-api:{S.RESET} {S.YELLOW}—{S.RESET} not yet polled")

        # Active source
        if _session:
            rows.append(f"  {S.DIM}active src:{S.RESET} {_session._last_src}")

        await message.edit(content=S.ui_box("lyricsync diag", rows))

    async def _status(self, message):
        cfg = _load_cfg()
        s = _session if is_active() else None
        rows = []
        state = "on" if (s or cfg.get("enabled")) else "off"
        if s:
            state += " (running)"
        rows.append(f"  {S.DIM}state:{S.RESET} {state}")
        if s:
            act = s._act
            if act:
                title  = _clean(act.get("details") or act.get("title"))
                artist = _clean(act.get("state")   or act.get("artist"))
                rows.append(f"  {S.DIM}track:{S.RESET} {title} — {artist}")
                if s.fetching:
                    rows.append(f"  {S.DIM}lyrics:{S.RESET} fetching...")
                elif s.lyrics is None:
                    rows.append(f"  {S.DIM}lyrics:{S.RESET} waiting")
                else:
                    rows.append(f"  {S.DIM}lyrics:{S.RESET} "
                                f"{len(s.lyrics)} lines")
                rows.append(f"  {S.DIM}line:{S.RESET} {s.last_text or '-'}")
                rows.append(f"  {S.DIM}src:{S.RESET} {s._last_src}")
            else:
                rows.append(f"  {S.DIM}track:{S.RESET} no spotify activity yet")
            rows.append(f"  {S.DIM}offset:{S.RESET} {s.offset_ms:+d}ms")
            rows.append(f"  {S.DIM}emoji:{S.RESET} {s.lyric_emoji or '(none)'}")
        else:
            rows.append(f"  {S.DIM}offset:{S.RESET} {cfg['offset_ms']:+d}ms")
            rows.append(f"  {S.DIM}emoji:{S.RESET} {cfg['emoji'] or '(none)'}")
        # Show age of the gateway presence signal
        pres_age = S.own_presence_age()
        rows.append(f"  {S.DIM}presence:{S.RESET} {_fmt_age(pres_age)}")
        # Show whether the Discord-API fallback has data
        api_ok = bool(_discord_api_result and
                      time.time() - _discord_api_result["at"] <= DISCORD_SPOTIFY_FRESH_MS / 1000.0)
        rows.append(f"  {S.DIM}discord-api:{S.RESET} {'fresh' if api_ok else 'no data'}")
        await message.edit(content=S.ui_box("lyricsync", rows))
