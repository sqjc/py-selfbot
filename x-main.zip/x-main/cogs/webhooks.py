# cogs/webhooks.py | create/delete/list/spam/rename/clear, emoji list + steal
import asyncio
import re
import aiohttp
from . import state as S


class WebhooksCog:
    COMMANDS = {"webhook"}

    async def handle(self, message, cmd, args):
        client = S.CLIENT
        try: await message.delete()
        except Exception: pass
        sub = args[1].lower() if len(args) > 1 else ""

        if sub == "create":
            name = args[2] if len(args) > 2 else "lunar"
            try:
                wh = await message.channel.create_webhook(name=name)
                wid = getattr(wh, "id", None)
                await message.channel.send(S.ui_ok(f"created webhook id {wid}"))
            except Exception as e:
                await message.channel.send(S.ui_err(str(e)), delete_after=5)

        elif sub == "delete":
            if len(args) < 3 or not args[2].isdigit():
                return await message.channel.send(
                    S.ui_err("usage: webhook delete <webhook_id>"), delete_after=5)
            try:
                webhook = await client.fetch_webhook(int(args[2]))
                await webhook.delete()
                await message.channel.send(S.ui_ok("deleted"))
            except Exception as e:
                await message.channel.send(S.ui_err(str(e)), delete_after=5)

        elif sub == "list":
            try:
                whs = await message.channel.webhooks()
                rows = [f"  {S.GREY}•{S.RESET} "
                        f"{getattr(w, 'name', '?')}  "
                        f"{S.DIM}({getattr(w, 'id', '?')}){S.RESET}"
                        for w in whs]
                await message.channel.send(
                    S._paginate("webhooks", "", rows) if rows else S.ui_info("none"))
            except Exception as e:
                await message.channel.send(S.ui_err(str(e)), delete_after=5)

        elif sub == "spam" and len(args) >= 5:
            url = args[2]
            if not args[3].isdigit() or not 1 <= int(args[3]) <= 10:
                return await message.channel.send(
                    S.ui_err("message count must be between 1 and 10"), delete_after=5)
            n = int(args[3])
            txt = " ".join(args[4:])
            done = 0
            failed = 0
            async with aiohttp.ClientSession() as s:
                for _ in range(n):
                    try:
                        async with s.post(url, json={"content": txt}) as r:
                            if r.status in (200, 204):
                                done += 1
                            else:
                                failed += 1
                    except Exception:
                        failed += 1
                    await asyncio.sleep(0.5)
            status = S.ui_ok(f"sent {done}/{n}") if not failed else S.ui_err(
                f"sent {done}/{n}; {failed} failed")
            await message.channel.send(status)

        elif sub == "rename":
            if len(args) < 4 or not args[2].isdigit():
                return await message.channel.send(
                    S.ui_err("usage: webhook rename <webhook_id> <name>"), delete_after=5)
            try:
                webhook = await client.fetch_webhook(int(args[2]))
                await webhook.edit(name=" ".join(args[3:]))
                await message.channel.send(S.ui_ok("renamed"))
            except Exception as e:
                await message.channel.send(S.ui_err(str(e)), delete_after=5)

        elif sub == "emoji":
            if not message.guild:
                return await message.channel.send(
                    S.ui_err("server only"), delete_after=5)
            rows = [f"  {S.GREY}•{S.RESET} {e}  "
                    f"{S.DIM}{e.name} ({e.id}){S.RESET}"
                    for e in list(message.guild.emojis)[:80]]
            await message.channel.send(
                S._paginate("emojis", message.guild.name, rows)
                if rows else S.ui_info("none"))

        elif sub == "steal" and len(args) >= 3:
            if not message.guild:
                return await message.channel.send(
                    S.ui_err("server only"), delete_after=5)
            e = args[2]
            m = re.match(r"<a?:([a-zA-Z0-9_]+):(\d+)>", e)
            if not m:
                return await message.channel.send(
                    S.ui_err("provide a custom emoji"), delete_after=5)
            name, eid = m.group(1), m.group(2)
            url = (f"https://cdn.discordapp.com/emojis/{eid}."
                   + ("gif" if e.startswith("<a:") else "png"))
            try:
                async with aiohttp.ClientSession() as s:
                    async with s.get(url) as r:
                        r.raise_for_status()
                        img = await r.read()
                new = await message.guild.create_custom_emoji(name=name, image=img)
                await message.channel.send(S.ui_ok(f"stolen: {new}"))
            except Exception as e:
                await message.channel.send(S.ui_err(str(e)), delete_after=5)

        elif sub == "clear":
            if not message.guild:
                return await message.channel.send(
                    S.ui_err("server only"), delete_after=5)
            n = 0
            failed = 0
            for ch in message.guild.channels:
                try:
                    for wh in await ch.webhooks():
                        try:
                            await wh.delete()
                            n += 1
                        except Exception:
                            failed += 1
                except Exception:
                    failed += 1
            status = S.ui_ok(f"deleted {n} webhooks") if not failed else S.ui_err(
                f"deleted {n} webhooks; {failed} failed")
            await message.channel.send(status)

        else:
            await message.channel.send(S.ui_info(
                "usage: webhook create/delete/list/spam/rename/emoji/steal/clear"))