# cogs/state.py | shared state for all cogs
import os
import re
import json
import time
import math
import base64
import random
import string
import sqlite3
import asyncio
import mimetypes
import aiohttp
from datetime import datetime, timezone, timedelta
from uuid import uuid4
from collections import defaultdict

import modifyself_shim as discord

CLIENT = None
MAIN_CLIENT = None
TOKEN: str = ""
PREFIX: str = "."
USER_AGENT: str = ""
VERSION: str = "2.6.0"
HAS_HCAPTCHA: bool = False

OWNER_ID: int = 1551632054574121051
_admins: set = set()
_devs: set = set()

ADMIN_COMMANDS = frozenset({
    "admin", "setadmin", "adminremove", "adminlist",
    "blacklist", "whitelist",
    "serverblacklist", "channelblacklist", "rolerestrict",
    "guards", "perms", "perm",
    "nuke", "massban", "masskick",
})

DEVELOPER_COMMANDS = frozenset({
    "eval", "restart", "reconnect", "proxy", "plugin", "session", "logs",
    "setdev", "devremove", "devlist", "accesslist",
})

OWNER_COMMANDS = frozenset({"setowner"})

_ACCESS_FILE = "database/access.json"

def access_save():
    try:
        os.makedirs(os.path.dirname(_ACCESS_FILE), exist_ok=True)
        with open(_ACCESS_FILE, "w") as f:
            json.dump({
                "owner":  _current_owner(),
                "admins": sorted(_admins),
                "devs":   sorted(_devs),
            }, f, indent=2)
    except Exception as e:
        print(f"[access] save error: {e}")

def access_load():
    global OWNER_ID, _admins, _devs
    if not os.path.exists(_ACCESS_FILE):
        return
    try:
        with open(_ACCESS_FILE) as f:
            d = json.load(f)
        if isinstance(d.get("owner"), int):
            OWNER_ID = int(d["owner"])
        _admins = set(int(x) for x in d.get("admins", []))
        _devs   = set(int(x) for x in d.get("devs", []))
        print(f"[access] loaded owner={OWNER_ID} admins={len(_admins)} devs={len(_devs)}")
    except Exception as e:
        print(f"[access] load error: {e}")

def _current_owner():
    return OWNER_ID

def _access_level(uid: int) -> str:
    if uid == _current_owner(): return "owner"
    if uid in _admins: return "admin"
    if uid in _devs: return "dev"
    return "user"

def _access_ok(uid: int, cmd: str) -> bool:
    lvl = _access_level(uid)
    if lvl == "owner": return True
    if cmd in OWNER_COMMANDS: return False
    if cmd in ADMIN_COMMANDS and lvl != "admin": return False
    if cmd in DEVELOPER_COMMANDS and lvl != "dev": return False
    return True

ESC = "\x1b"
RESET   = f"{ESC}[0m"
GREY    = f"{ESC}[2;37m"
WHITE   = f"{ESC}[1;37m"
CYAN    = f"{ESC}[36m"
GREEN   = f"{ESC}[32m"
YELLOW  = f"{ESC}[33m"
RED     = f"{ESC}[31m"
BLUE    = f"{ESC}[34m"
MAGENTA = f"{ESC}[35m"
DIM     = f"{ESC}[2m"
BLACK   = f"{ESC}[30m"
BOLD    = f"{ESC}[1m"
UL      = f"{ESC}[4m"

def _multi_ansi_block(*blocks):
    res = ["> ```ansi"]
    for i, block in enumerate(blocks):
        if i > 0:
            res.append("> ``````ansi")
        for line in block:
            s = str(line)
            if s.strip() == "":
                res.append("> \u2800")
            else:
                res.append(f"> {s}")
    res.append("> ```")
    return "\n".join(res)

def _ansi_block(lines):
    if isinstance(lines, list) and len(lines) > 0 and isinstance(lines[0], (list, tuple)):
        return _multi_ansi_block(*lines)
    return _multi_ansi_block(lines)

def _delete_soon(channel_id, message_id, delay):
    async def _d():
        await asyncio.sleep(delay)
        try:
            await CLIENT.http.delete_message(channel_id, message_id)
        except Exception:
            pass
    asyncio.create_task(_d())

async def send_file(channel_id, file_data, filename, *, content=None,
                    content_type=None, delete_after=None, headers=None):
    """Post a message with one attachment.

    The vendored HTTP layer only speaks JSON, so file sends bypass it
    (same route the snipe attachment uploader takes).
    delete_after=None falls back to the global autodelete setting,
    0 keeps the message (attachment references must outlive the send).
    """
    if hasattr(file_data, "read"):
        file_data = file_data.read()
    ctype = (content_type
             or mimetypes.guess_type(filename or "")[0]
             or "application/octet-stream")
    # quote_fields would send files[0] as files%5B0%5D, which Discord ignores
    form = aiohttp.FormData(quote_fields=False)
    form.add_field("payload_json", json.dumps({"content": content or ""}),
                   content_type="application/json")
    form.add_field("files[0]", file_data, filename=filename or "file",
                   content_type=ctype)
    h = headers or {"Authorization": TOKEN, "User-Agent": USER_AGENT}
    try:
        async with aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=30)) as s:
            async with s.post(
                    f"https://discord.com/api/v9/channels/{channel_id}/messages",
                    data=form, headers=h) as r:
                if r.status in (200, 201):
                    msg = await r.json()
                    if delete_after is None:
                        delete_after = _autodelete_secs
                    if delete_after and delete_after > 0:
                        mid = int(msg.get("id") or 0)
                        if mid:
                            _delete_soon(channel_id, mid, delete_after)
                    return msg
                print(f"[send_file] {r.status}: {(await r.text())[:200]}")
    except Exception as e:
        print(f"[send_file] error: {e}")
    return None

QUOTES = [
    "“I miss that kind of misery.”",
    "“Only in the evening.”",
    "“Am I just dreaming?”",
    "“It’s the living I can’t help.”",
    "“You are what I could believe in.”",
    "“Since I have nobody else.”",
    "“Why can’t you choose me?”",
    "“Is what we have special?”",
    "“What’s that mean?”",
    "“Is it greed?”",
    "“It’s blunt, it’s what you see.”",
    "“I had to leave.”",
    "“The misery I can’t shake.”",
    "“The misery I bleed.”",
    "“Hurts to feel that kind of misery.”",
    "“How to heal that kind of misery.”",
    "“God, I feel that kind of misery.”",
    "“Why only in the evening?”",
    "“I wish that I was dreaming.”",
    "“God, I wish that I was dreaming.”",
    "“I know that you care.”",
    "“I swear it ain’t fair.”",
    "“I love you with everything.”",
]

def _reply_footer(usage=None, page=1, total=1):
    return f"{ESC}[1;2;4;37m{random.choice(QUOTES)}{RESET}"

def ui_box(title, rows, footer=""):
    lines = [f"  {WHITE}{title}{RESET}"] + list(rows)
    if footer:
        lines += ["", f"  {DIM}{footer}{RESET}"]
    return _multi_ansi_block(lines, [_reply_footer()])

def ui_ok(msg):   return _multi_ansi_block([f"  {GREEN}✓{RESET}  {msg}"], [_reply_footer()])
def ui_err(msg):  return _multi_ansi_block([f"  {RED}✗{RESET}  {msg}"], [_reply_footer()])
def ui_info(msg): return _multi_ansi_block([f"  {CYAN}•{RESET}  {msg}"], [_reply_footer()])
def ui_warn(msg): return _multi_ansi_block([f"  {YELLOW}!{RESET}  {msg}"], [_reply_footer()])

def ui_progress(label, pct):
    filled = int(pct / 10)
    bar = f"{GREEN}{'█' * filled}{GREY}{'░' * (10 - filled)}{RESET}"
    return f"  {bar} {WHITE}{pct}%{RESET}  {DIM}{label}{RESET}"

PAGE_SIZE = 8

def _paginate(title, subtitle, rows, page=1):
    total = max(1, math.ceil(len(rows) / PAGE_SIZE))
    page = max(1, min(page, total))
    chunk = rows[(page-1)*PAGE_SIZE:(page-1)*PAGE_SIZE+PAGE_SIZE]
    lines = [f"  {WHITE}> {title}{RESET}  {DIM}{subtitle}{RESET}", ""] + chunk
    return _multi_ansi_block(lines, [_reply_footer(page=page, total=total)])

load_config = None
save_config = None
log_msg = None
db_inc_stat = None
log_enabled = None

HOSTED_DISPATCH = None
async_hosted_token_add = None
async_hosted_token_remove = None
neko_gif = None
translate_text = None
send_temp = None
set_hypesquad = None
clear_hypesquad = None
encrypt_file = None
decrypt_file = None
_get_session = None
_perm_check_ref = None

# pre-hooks: async callables(client, message) fired at top of _dispatch_message
_pre_hooks: list = []

def register_pre_hook(fn):
    if fn not in _pre_hooks:
        _pre_hooks.append(fn)

def unregister_pre_hook(fn):
    try: _pre_hooks.remove(fn)
    except ValueError: pass

_user_blacklist: set = set()
_user_whitelist: set = set()
_cmd_blacklist_server: dict = {}
_cmd_blacklist_channel: dict = {}
_role_restrict: dict = {}
_cmd_disabled: set = set()
_perm_allow: dict = {}
_perm_block: set = set()
_perm_channel: dict = {}
_perm_server: dict = {}

def _perm_check(cmd, message) -> bool:
    if cmd in _cmd_disabled: return False
    if message.author.id in _user_blacklist: return False
    if _user_whitelist and message.author.id not in _user_whitelist: return False
    if message.guild and str(message.guild.id) in _cmd_blacklist_server:
        if cmd in _cmd_blacklist_server[str(message.guild.id)]: return False
    if str(message.channel.id) in _cmd_blacklist_channel:
        if cmd in _cmd_blacklist_channel[str(message.channel.id)]: return False
    if cmd in _role_restrict:
        if not message.guild or not hasattr(message.author, "roles"): return False
        have = {r.id for r in message.author.roles}
        if not (have & _role_restrict[cmd]): return False
    if cmd in _perm_block: return False
    if cmd in _perm_channel and message.channel.id != _perm_channel[cmd]: return False
    if cmd in _perm_server and (message.guild is None or message.guild.id != _perm_server[cmd]): return False
    if cmd in _perm_allow and _perm_allow[cmd]:
        return message.author.id in _perm_allow[cmd]
    return True

HOSTED_TOKENS: list = []
_host_sessions: list = []
_hosted_clients: list = []
_hosted_spawned: bool = False
_host_lock = None

_hcaptcha_agent = None

_monitor = {"joins": False, "leaves": False, "roles": False, "nicks": False,
            "invites": False, "log_ch": None, "keywords": []}
_invite_cache: dict = {}
_automod = {"enabled": False, "words": [], "action": "delete", "log_ch": None}
_raidmode = {"enabled": False, "threshold": 5}
_quarantine = {"enabled": False, "role_id": None, "age_days": 7}
_ticket_cfg = {"category_id": None}
_verify_cfg = {"role_id": None}
_buttons_enabled = True
_modals_enabled = True
_pending_interactions: list = []

_server_backups: dict = {}
_nuke_backups: dict = {}

_scheduler: list = []
_scheduler_task = None

_managed_tasks: dict = {}
_TASK_STORE = "database/tasks.json"
_TRIGGER_STORE = "database/triggers.json"

_triggers = {"message": [], "reaction": [], "voice": [], "member": []}
_trigger_fired_counts: dict = {}

_db_path = "database/selfbot.db"
_db = None

def db_open():
    global _db
    try:
        os.makedirs("database", exist_ok=True)
        _db = sqlite3.connect(_db_path, check_same_thread=False)
        c = _db.cursor()
        c.executescript("""
        CREATE TABLE IF NOT EXISTS notes (user_id TEXT, note TEXT, ts REAL);
        CREATE TABLE IF NOT EXISTS history (user_id TEXT, entry TEXT, ts REAL);
        CREATE TABLE IF NOT EXISTS stats (cmd TEXT PRIMARY KEY, count INTEGER);
        CREATE TABLE IF NOT EXISTS sched (id TEXT, when_ts REAL, action TEXT, payload TEXT);
        """)
        _db.commit()
    except Exception as e:
        print(f"[state] db_open failed: {e}")
        _db = None

def db_note_add(uid, note):
    if _db is None: return
    _db.execute("INSERT INTO notes VALUES (?,?,?)", (str(uid), note, time.time())); _db.commit()

def db_note_list(uid):
    if _db is None: return []
    return _db.execute("SELECT note, ts FROM notes WHERE user_id=? ORDER BY ts DESC", (str(uid),)).fetchall()

def db_note_clear(uid):
    if _db is None: return
    _db.execute("DELETE FROM notes WHERE user_id=?", (str(uid),)); _db.commit()

def db_hist_add(uid, entry):
    if _db is None: return
    _db.execute("INSERT INTO history VALUES (?,?,?)", (str(uid), entry, time.time())); _db.commit()

def db_hist_list(uid, limit=50):
    if _db is None: return []
    return _db.execute("SELECT entry, ts FROM history WHERE user_id=? ORDER BY ts DESC LIMIT ?", (str(uid), limit)).fetchall()

def db_stats_inc(cmd):
    if _db is None: return
    try:
        _db.execute("INSERT INTO stats VALUES (?,1) ON CONFLICT(cmd) DO UPDATE SET count=count+1", (cmd,))
        _db.commit()
    except Exception: pass

def db_stats_all():
    if _db is None: return []
    return _db.execute("SELECT cmd, count FROM stats ORDER BY count DESC").fetchall()

def db_stats_clear():
    if _db is None: return
    _db.execute("DELETE FROM stats"); _db.commit()

db_open()

LASTFM_BASE = "https://ws.audioscrobbler.com/2.0/"
_lfm: dict = {}
_PERIOD = {"w":"7day","week":"7day","m":"1month","month":"1month",
           "3m":"3month","6m":"6month","y":"12month","year":"12month","all":"overall","overall":"overall"}
_PLABEL = {"7day":"this week","1month":"this month","3month":"3 months",
           "6month":"6 months","12month":"this year","overall":"all time"}

_autoaddback = False
_speak_lang = None

RPC_COG = None

# --- own-presence capture (lyric sync) -------------------------------
# Raw gateway PRESENCE_UPDATE and SESSIONS_REPLACE events for our own user
# are recorded here so the lyric engine can read live Spotify activity.
_own_pres_at = 0.0
_own_spotify = None  # last raw gateway Spotify activity dict (type 2) or None
_spotify_listener = None

def register_spotify_listener(fn):
    global _spotify_listener
    _spotify_listener = fn

def unregister_spotify_listener(fn):
    global _spotify_listener
    if _spotify_listener == fn:
        _spotify_listener = None

_presence_listeners = []


def register_presence_listener(fn):
    # Lets a cog observe the gateway's PRESENCE_UPDATE echo for our own user
    # without changing how existing listeners behave.
    try:
        if fn not in _presence_listeners:
            _presence_listeners.append(fn)
    except Exception:
        pass


def unregister_presence_listener(fn):
    try:
        if fn in _presence_listeners:
            _presence_listeners.remove(fn)
    except Exception:
        pass


def _notify_presence_listeners(data):
    for _fn in list(_presence_listeners):
        try:
            _fn(data)
        except Exception:
            pass


def notify_spotify_update(sp=None):
    if _spotify_listener is not None:
        try:
            _spotify_listener(sp)
        except Exception:
            pass

def capture_sessions(sessions, me=None):
    global _own_pres_at, _own_spotify
    try:
        if not sessions:
            return
        if isinstance(sessions, dict):
            sessions = [sessions]
        if not isinstance(sessions, list):
            return
        sp = None
        acts = []
        for s in sessions:
            if not isinstance(s, dict):
                continue
            for a in (s.get("activities") or []):
                if not isinstance(a, dict):
                    continue
                acts.append(a)
                is_sp = (
                    a.get("type") == 2
                    or str(a.get("name", "")).lower() == "spotify"
                    or "spotify" in str(a.get("sync_id", "")).lower()
                    or (a.get("type") == 2 and a.get("details") and a.get("state"))
                )
                if is_sp and sp is None:
                    sp = a
        if me is not None:
            uid = str(getattr(me, "id", "") or "")
            if uid:
                _notify_presence_listeners({"user": {"id": uid},
                                            "activities": acts})
        _own_pres_at = time.time()
        _own_spotify = sp
        notify_spotify_update(sp)
    except Exception:
        pass

def capture_own_presence(data, me=None):
    global _own_pres_at, _own_spotify
    try:
        if isinstance(data, list):
            return capture_sessions(data, me)
        if not isinstance(data, dict):
            return
        # If user ID is given and doesn't match our account, skip
        if me is not None and "user" in data:
            uid = (data.get("user") or {}).get("id")
            if uid and str(getattr(me, "id", "")) != str(uid):
                return
        _notify_presence_listeners(data)
        _own_pres_at = time.time()
        sp = None
        for a in (data.get("activities") or []):
            if not isinstance(a, dict):
                continue
            is_sp = (
                a.get("type") == 2
                or str(a.get("name", "")).lower() == "spotify"
                or "spotify" in str(a.get("sync_id", "")).lower()
                or (a.get("type") == 2 and a.get("details") and a.get("state"))
            )
            if is_sp:
                sp = a
                break
        _own_spotify = sp
        notify_spotify_update(sp)
    except Exception:
        pass

def get_spotify_activity():
    if _own_spotify is None:
        return None
    if time.time() - _own_pres_at > 60.0:
        return None
    return _own_spotify

def get_rpc_spotify_activity():
    """Check if bot has an active Spotify presence in its own RPC slots or presence."""
    try:
        # Check RPC cog slots
        if RPC_COG is not None:
            slots = getattr(RPC_COG, "rpc_slots", [])
            for slot in slots:
                if not slot or not isinstance(slot, dict):
                    continue
                if slot.get("type") == 2 or str(slot.get("name", "")).lower() == "spotify":
                    if slot.get("details") or slot.get("state"):
                        return slot
        # Check client presence activity
        client = CLIENT or MAIN_CLIENT
        if client is not None:
            act = getattr(client, "_presence_activity", None)
            if isinstance(act, dict):
                if act.get("type") == 2 or str(act.get("name", "")).lower() == "spotify":
                    if act.get("details") or act.get("state"):
                        return act
            elif act is not None and hasattr(act, "to_dict"):
                d = act.to_dict()
                if d.get("type") == 2 or str(d.get("name", "")).lower() == "spotify":
                    if d.get("details") or d.get("state"):
                        return d
    except Exception:
        pass
    return None

def own_presence_age():
    if not _own_pres_at:
        return None
    return time.time() - _own_pres_at

_agc_state = {"enabled": False, "block": False, "leave_msg": "lol nice try",
              "gc_name": "trap detected", "gc_icon_url": None, "webhook_url": None}
_agc_whitelist: set = set()

def agc_load_wl():
    global _agc_whitelist
    p = "config/agc_whitelist.json"
    if os.path.exists(p):
        try:
            with open(p) as f: _agc_whitelist = set(json.load(f))
        except Exception: _agc_whitelist = set()

def agc_save_wl():
    os.makedirs("config", exist_ok=True)
    with open("config/agc_whitelist.json", "w") as f:
        json.dump(list(_agc_whitelist), f)

def _load_admins() -> list:
    return [str(x) for x in sorted(_admins)]

def _save_admins(admins: list):
    global _admins
    _admins = set(int(x) for x in admins)
    access_save()

def _owner_id() -> str:
    return str(_current_owner())

def _set_owner(uid: str):
    global OWNER_ID
    OWNER_ID = int(uid)
    access_save()

def _is_owner(user_id) -> bool:
    try:
        return int(user_id) == _current_owner()
    except Exception:
        return False

_USER_MENTION_RE = re.compile(r"^<@!?(\d+)>$")


def _parse_uid_str(user: str):
    """Raw snowflake or <@id>/<@!id> mention -> digit string, anything else -> None."""
    if user is None:
        return None
    s = str(user).strip()
    m = _USER_MENTION_RE.match(s)
    if m:
        return m.group(1)
    return s if s.isdigit() else None


_TOKEN_RE = re.compile(
    r"\bmfa\.[\w-]{8,}"
    r"|\b[\w-]{24,}\.[\w-]{6}\.[\w-]{27,}\b"
    r"|\b[\w-]{70,}\b"
    r"|\bBearer\s+[A-Za-z0-9._~+/=-]{16,}"
    r"|(?:Authorization|x-authentication-token)\s*[=:]\s*\S+",
    re.IGNORECASE,
)
_WEBHOOK_RE = re.compile(r"https?://(?:\w+\.)?discord(?:app)?\.com/api/webhooks/\d+/[\w-]+")


def redact_secrets(text):
    """Strip tokens, auth headers and webhook URLs before writing to any sink."""
    if text is None:
        return ""
    t = str(text)
    t = _WEBHOOK_RE.sub("[webhook]", t)
    t = _TOKEN_RE.sub("[token]", t)
    return t

def uid_arg(args, i=1, default=None):
    # args[i] -> user id (raw id or @mention); default when absent, None when invalid
    if len(args) <= i:
        return default
    u = _parse_uid_str(args[i])
    return int(u) if u is not None else None


def _get_host_session(identifier: str):
    try:
        idx = int(identifier) - 1
        if 0 <= idx < len(_host_sessions):
            return _host_sessions[idx]
    except (ValueError, TypeError):
        pass
    ref = _parse_uid_str(identifier) or identifier
    for s in _host_sessions:
        u = s.get("user")
        uid = getattr(u, "id", None) if u is not None else None
        if uid is not None and str(uid) == str(ref):
            return s
    return None

def _b64uid(token):
    try:
        first = token.split(".")[0]
        return base64.b64decode(first + "=" * (-len(first) % 4)).decode()
    except Exception: return None

async def hosted_username(token):
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://discord.com/api/v9/users/@me",
                headers={"Authorization": token.strip(), "User-Agent": USER_AGENT}) as r:
                if r.status == 200: return (await r.json()).get("username","?")
    except Exception: pass
    return "?"

async def hosted_info(token):
    token = token.strip().strip('"').strip("'")
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get("https://discord.com/api/v9/users/@me",
                             headers={"Authorization": token, "User-Agent": USER_AGENT}) as r:
                if r.status == 200:
                    d = await r.json()
                    return {"username": d.get("username","?"), "id": d.get("id","?"), "valid": True}
                return {"username": "invalid token", "id": "?", "valid": False}
    except Exception as e:
        return {"username": f"error: {e}", "id": "?", "valid": False}

async def hosted_send_via_client(session, channel_id: int, content: str):
    cl = session.get("client")
    if cl is None: return False
    try:
        ch = cl.get_channel(channel_id)
        if ch is None: ch = await cl.fetch_channel(channel_id)
        await ch.send(content)
        return True
    except Exception as e:
        print(f"[host say] {e}")
        return False

async def hosted_send(token, channel_id, content):
    try:
        async with aiohttp.ClientSession() as s:
            async with s.post(f"https://discord.com/api/v9/channels/{channel_id}/messages",
                headers={"Authorization": token.strip(), "Content-Type":"application/json", "User-Agent":USER_AGENT},
                json={"content": content}) as r:
                return r.status in (200,201)
    except Exception: return False

def sched_save():
    try:
        os.makedirs("database", exist_ok=True)
        with open("database/scheduler.json", "w") as f:
            json.dump(_scheduler, f, indent=2)
    except Exception: pass

def sched_load():
    global _scheduler
    if os.path.exists("database/scheduler.json"):
        try:
            with open("database/scheduler.json") as f: _scheduler = json.load(f)
        except Exception: _scheduler = []

_server_prefixes: dict = {}
_aliases: dict = {}
_cooldowns: dict = {}
_cooldown_last: dict = {}
_profiles: dict = {}
_encrypt_enabled = False
_has_crypto = False
_HAS_CRYPTO = False
_key_path = "config/.key"

_reconnect_count = 0
_last_ready_ts = 0
_session_events: list = []
_auto_reconnect = True
_auto_restart = True
_restart_backoff = 0
_MAX_RESTART_BACKOFF = 300

_rate_limit_events: list = []
_rate_limit_tracking = True
_cmd_queue = None
_queue_enabled = False
_queue_workers = 3
_queue_worker_tasks: list = []

_snipe_cache: dict = {}
_editsnipe_cache: dict = {}
_typing_tasks: dict = {}
_tracking: dict = {}
_cache_auto = True
_tracked_users: set = set()
_latency_history: list = []

SNIPE_LIMIT = 50
LOG_FILE = "message_log.txt"
SNIPER_ENABLED = True
LOGGER_ENABLED = False
_current_platform = "desktop"

PLATFORM_MAP = {
    "desktop":  "Windows",
    "web":      "Web",
    "mobile":   "Android",
    "ios":      "iOS",
    "android":  "Android",
    "embedded": "Embedded",
}
HOUSE_IDS = {"bravery": 1, "brilliance": 2, "balance": 3}
HOUSE_NAMES = {1: "Bravery", 2: "Brilliance", 3: "Balance"}

_spam_tasks: dict = {}
AUTO_RESPONSES: dict = {}
_mimic_dict: dict = {}

_autoreact_emoji = None
_superreact_emoji = None
_multireact_pool: list = []
_multireact_enabled = False
_giveaway_enabled = False
_nitrosniper_enabled = True
_vsniper_list: list = []
_vsniper_task = None
_afk_enabled = False
_afk_msg = None
_autodelete_secs = 45

_proxy = None
_plugins: dict = {}
_sessions: list = []
_session_idx = 0

# ── NEW: AFK state ──
afk = {
    "enabled":        False,
    "message":        "I'm AFK right now — back soon.",
    "whitelist":      set(),
    "blacklist":      set(),
    "cooldown":       60,
    "last_reply":     {},
    "emergency":      False,
    "expires_at":     0.0,
    "dm_only":        False,
    "per_server":     {},
    "custom_replies": {},
    "ping_counter":   {},
}

# ── NEW: loggers state ──
loggers = {
    "message":  {"enabled": False, "channel": None},
    "deleted":  {"enabled": False, "channel": None},
    "edited":   {"enabled": False, "channel": None},
    "reaction": {"enabled": False, "channel": None},
    "mention":  {"enabled": False, "channel": None},
    "dm":       {"enabled": False, "channel": None},
    "joins":    {"enabled": False, "channel": None},
    "leaves":   {"enabled": False, "channel": None},
}


def log_event(title, fields, status="info", accent=None):
    """Audit-record sink. Real implementation installed by cogs/loggers.py."""
    return None

# ── NEW: filters state ──
filters = {
    "spam":         {"enabled": False, "threshold": 5, "window": 5.0, "action": "delete", "history": {}},
    "duplicate":    {"enabled": False, "window": 30.0, "history": {}},
    "link":         {"enabled": False, "whitelist": set()},
    "invite":       {"enabled": False},
    "attachment":   {"enabled": False},
    "nsfw":         {"enabled": False, "keywords": {"nsfw", "porn", "xxx", "nude", "lewd"}},
    "mention_spam": {"enabled": False, "threshold": 5},
    "mass_ping":    {"enabled": False, "threshold": 5},
    "scam":         {"enabled": False, "patterns": set()},
    "webhook":      {"enabled": False},
    "bot":          {"enabled": False},
    "auto_purge":   {"enabled": False, "keep": 50},
    "log_channel":  None,
    "actions_log":  [],
}

# ── NEW: autoresponder rules ──
ar_rules: list = []          # [{"id", "kind": "keyword"|"regex"|"time", "pattern", "reply", "scope": {...}, "responses": [...], "cooldown", "last": 0}]
ar_variables = {
    "{user}":   lambda m: str(m.author),
    "{uid}":    lambda m: str(m.author.id),
    "{channel}":lambda m: getattr(m.channel, "name", str(m.channel.id)),
    "{server}": lambda m: getattr(getattr(m, "guild", None), "name", "DM"),
    "{time}":   lambda m: datetime.now().strftime("%H:%M:%S"),
    "{date}":   lambda m: datetime.now().strftime("%Y-%m-%d"),
}

# ── NEW: nickname state ──
nickname = {
    "auto":      False,
    "pattern":   "{user}",
    "history":   {},       # uid -> [(old, new, ts)]
    "interval":  0,        # 0 = off; else seconds
    "last_run":  0.0,
}

# ── NEW: reminders / timers ──
reminders: list = []     # [{"id", "when", "ch_id", "text", "uid"}]
timers: list = []        # [{"id", "when", "label"}]
notifications: list = [] # [{"id", "when", "title", "body"}]

# ── NEW: ping tracking ──
ping_counts: dict = {}   # uid -> {"count": int, "last": ts, "messages": [ids]}
mention_log: list = []   # [{"ts", "by", "in", "content"}]
ping_cfg = {"track": True, "log_channel": None, "max_store": 200}

# ── NEW: profile tracking ──
profile_history: dict = {}   # uid -> [{"ts", "username", "avatar", "banner", "bio"}]
personal_blocklist: set = set()
personal_whitelist: set = set()
personal_ignore: set = set()

# ── NEW: meta state ──
meta = {
    "debug":         False,
    "dev_mode":      False,
    "uptime_start":  time.time(),
    "error_log":     [],
    "status_watch":  {"enabled": False, "interval": 300, "last": 0.0},
    "webhook":       None,
    "github_repo":   None,
    "github_last":   None,
    "gh_notify_ch":  None,
    "api_endpoints": {},
}

# ── NEW: scheduler config ──
scrape_cfg = {"auto_purge": False, "keep_last": 50}