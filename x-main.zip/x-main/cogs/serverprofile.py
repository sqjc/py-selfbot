# cogs/serverprofile.py | per-server (guild member) avatar, banner, bio, pronouns, display name
import json
import aiohttp
from . import state as S
from .profile import _profile_headers, _url_or_attachment_to_b64


_CDN = {"avatar": "https://cdn.discordapp.com/guilds/{gid}/users/{uid}/avatars/{h}.{ext}?size=512",
        "banner": "https://cdn.discordapp.com/guilds/{gid}/users/{uid}/banners/{h}.{ext}?size=600"}

_GET = {
    "serverpfp": "avatar", "spfp": "avatar", "sav": "avatar", "serverav": "avatar",
    "svb": "banner", "sbanner": "banner",
    "serverbio": "bio", "svbio": "bio", "sbio": "bio",
    "serverpronouns": "pronouns", "svpron": "pronouns", "spron": "pronouns",
    "serverdisplayname": "nick", "svdn": "nick",
}

# cmd -> (member field, takes an image url/attachment)
_SET = {
    "setserverpfp": ("avatar", True), "sspfp": ("avatar", True), "setspfp": ("avatar", True),
    "setserverbanner": ("banner", True), "ssbanner": ("banner", True),
    "setsbanner": ("banner", True),
    "setserverbio": ("bio", False), "ssbio": ("bio", False), "setsbio": ("bio", False),
    "setserverpronouns": ("pronouns", False), "sspron": ("pronouns", False),
    "setspron": ("pronouns", False),
    "setserverdisplayname": ("nick", False), "ssdn": ("nick", False),
    "setssdn": ("nick", False),
}

_CLEAR = {"clearserverpfp": "avatar", "cspfp": "avatar",
          "clearserverbio": "bio", "csbio": "bio"}

_STEAL = {
    "stealserverpfp": ("avatar",), "stspfp": ("avatar",),
    "stealserverbio": ("bio",), "stsbio": ("bio",),
    "serverclone": ("avatar", "banner", "bio", "pronouns"),
    "scopy": ("avatar", "banner", "bio", "pronouns"),
    "scl": ("avatar", "banner", "bio", "pronouns"),
}

_CLEAR_ALL = {"serverclearall", "sclrall", "sclear"}


def _gid(message):
    for value in (getattr(getattr(message, "guild", None), "id", None),
                  getattr(getattr(message, "channel", None), "guild_id", None),
                  getattr(message, "guild_id", None)):
        try:
            if value:
                return int(value)
        except (TypeError, ValueError):
            continue
    return None


class ServerProfileCog:
    COMMANDS = set(_GET) | set(_SET) | set(_CLEAR) | set(_STEAL) | _CLEAR_ALL

    async def _request(self, method, url, **kw):
        async with aiohttp.ClientSession() as s:
            async with s.request(method, url, headers=_profile_headers(), **kw) as r:
                text = await r.text()
                try:
                    body = json.loads(text)
                except Exception:
                    body = {}
                return r.status, body

    async def _member(self, gid, uid):
        status, body = await self._request(
            "GET", f"https://discord.com/api/v9/guilds/{gid}/members/{uid}")
        return body if status == 200 else None

    async def _patch_me(self, gid, payload):
        return await self._request(
            "PATCH", f"https://discord.com/api/v9/guilds/{gid}/members/@me", json=payload)

    @staticmethod
    def _asset_url(gid, uid, field, h):
        ext = "gif" if str(h).startswith("a_") else "webp"
        return _CDN[field].format(gid=gid, uid=uid, h=h, ext=ext)

    async def _show(self, message, gid, cmd, field, args):
        uid = S.uid_arg(args, 1, message.author.id)
        if uid is None:
            return await message.edit(content=S.ui_err(f"usage: {cmd} [user_id]"))
        m = await self._member(gid, uid)
        if m is None:
            return await message.edit(content=S.ui_err("member not in this server"))
        value = m.get(field)
        if field in _CDN and value:
            return await message.edit(content=self._asset_url(gid, uid, field, value))
        await message.edit(content=S.ui_box(f"server {field}", [
            f"  {S.DIM}user{S.RESET}     {m.get('nick') or uid}",
            f"  {S.DIM}{field}{S.RESET}  {value or 'none'}",
        ]))

    async def _set(self, message, gid, cmd, field, image, args):
        if image:
            raw = args[1] if len(args) > 1 else ""
            if not raw and not getattr(message, "attachments", None):
                return await message.edit(content=S.ui_err(
                    f"usage: {cmd} <url | attach image | remove>"))
            try:
                value = await _url_or_attachment_to_b64(raw, message)
            except Exception as e:
                return await message.edit(content=S.ui_err(f"could not fetch image: {e}"))
            if value == "CLEAR":
                value = None
        else:
            value = " ".join(args[1:]) or None
            if value is None:
                return await message.edit(content=S.ui_err(f"usage: {cmd} <text>"))
        status, _ = await self._patch_me(gid, {field: value})
        await message.edit(content=S.ui_ok(f"server {field} updated")
                                  if status in (200, 204) else S.ui_err(f"failed {status}"))

    async def _steal(self, message, gid, cmd, fields, args):
        uid = S.uid_arg(args, 1)
        if uid is None:
            return await message.edit(content=S.ui_err(f"usage: {cmd} <user_id>"))
        m = await self._member(gid, uid)
        if m is None:
            return await message.edit(content=S.ui_err("member not in this server"))
        payload = {}
        for field in fields:
            value = m.get(field)
            if not value:
                continue
            if field in _CDN:
                try:
                    value = await _url_or_attachment_to_b64(
                        self._asset_url(gid, uid, field, value), message)
                except Exception as e:
                    return await message.edit(content=S.ui_err(f"could not fetch {field}: {e}"))
            payload[field] = value
        if not payload:
            return await message.edit(content=S.ui_info("nothing to copy"))
        status, _ = await self._patch_me(gid, payload)
        await message.edit(content=S.ui_ok(f"copied: {', '.join(payload)}")
                                  if status in (200, 204) else S.ui_err(f"failed {status}"))

    async def handle(self, message, cmd, args):
        gid = _gid(message)
        if gid is None:
            return await message.edit(content=S.ui_err("run this inside a server"))

        if cmd in _GET:
            return await self._show(message, gid, cmd, _GET[cmd], args)

        if cmd in _SET:
            field, image = _SET[cmd]
            return await self._set(message, gid, cmd, field, image, args)

        if cmd in _CLEAR:
            field = _CLEAR[cmd]
            status, _ = await self._patch_me(gid, {field: None})
            return await message.edit(content=S.ui_ok(f"server {field} cleared")
                                              if status in (200, 204)
                                              else S.ui_err(f"failed {status}"))

        if cmd in _STEAL:
            return await self._steal(message, gid, cmd, _STEAL[cmd], args)

        if cmd in _CLEAR_ALL:
            status, _ = await self._patch_me(gid, {"avatar": None, "banner": None,
                                                   "bio": "", "pronouns": "", "nick": None})
            return await message.edit(content=S.ui_ok("server profile reset")
                                              if status in (200, 204)
                                              else S.ui_err(f"failed {status}"))
