# cogs/rpc_adapter.py | bridges RPCCog into the selfbot dispatcher
import asyncio
import traceback
import modifyself_shim as discord
from . import state as S


class RpcAdapterCog:
    COMMANDS = {"rpc", "rpc1", "rpc2", "rpc3", "rpc4", "rpc5", "rpc6",
                "playing", "listening", "listen", "watching", "watch",
                "competing", "stopactivity", "aoff", "clear_multi_rpc",
                "rpc_status", "spotify", "youtube", "xbox", "ps", "ps4",
                "crunchy", "vrchat", "meta", "rstatus", "remoji",
                "stopstatus", "stopemoji", "setpresencestatus", "roblox",
                "rpcwatchdog"}

    _ALIASES = {
        "listen": "listening",
        "watch":  "watching",
    }

    def __init__(self):
        self._inner = None

    def register(self, client):
        try:
            from cogs.rpc import RPCCog
        except Exception as e:
            print(f"[rpc-adapter] cannot import cogs.rpc: {e}")
            traceback.print_exc()
            self._inner = None
            return
        try:
            self._inner = RPCCog(client)
        except Exception as e:
            print(f"[rpc-adapter] RPCCog init failed: {e}")
            traceback.print_exc()
            self._inner = None
            return

        try:
            self._inner.register(client)
            S.RPC_COG = self._inner
        except Exception as e:
            print(f"[rpc-adapter] inner register failed: {e}")
            traceback.print_exc()

        print("[rpc-adapter] RPCCog loaded")

    async def handle(self, message, cmd, args):
        if self._inner is None:
            try:
                await message.channel.send(S.ui_err("rpc cog not loaded — see console"))
            except Exception:
                pass
            return

        if cmd == "rpc":
            sub = args[1].lower() if len(args) > 1 else ""
            if sub == "status":
                await self._inner.handle(message, "rpc_status", args)
                return
            if sub == "clearall":
                await self._inner.handle(message, "clear_multi_rpc", args)
                return
            if sub.isdigit() and 1 <= int(sub) <= 6:
                slot = f"rpc{int(sub)}"
                await self._inner.handle(message, slot, [slot] + args[2:])
                return
            await self._usage(message)
            return

        cmd = self._ALIASES.get(cmd, cmd)

        try:
            await self._inner.handle(message, cmd, args)
        except Exception as e:
            print(f"[rpc-adapter:{cmd}] {e}")
            traceback.print_exc()
            try:
                await message.channel.send(
                    S.ui_err(f"rpc `{cmd}` errored — check console"))
            except Exception:
                pass

    _MENU = (
        ("rpc <1-6> <field> <value>", "set a slot"),
        ("rpc status / clearall", "show slots / wipe every slot"),
        None,
        ("rpc1 <field> <value>", "slot shorthand - rpc1..rpc6"),
        ("name / details / state", "activity text lines"),
        ("type <type>", "playing/streaming/listening/watching/competing"),
        ("platform <preset>", "xbox/ps/ps4/crunchyroll/youtube/twitch/vrchat/meta/roblox"),
        ("large_image / small_image", "image url"),
        ("timestamp <val>", "3600 | 1:00:00 | clear"),
        ("btn1 / btn2 <label> <url>", "profile buttons"),
        ("clear", "wipe that slot"),
        None,
        ("spotify <song - artist>", "quick presence, [slot] optional"),
        ("youtube <video - channel>", "quick presence, [slot] optional"),
        ("roblox <game> [- details]", "quick presence, [slot] optional"),
        ("xbox / ps / ps4 / crunchy", "quick game presets"),
        ("vrchat / meta", "quick world presets"),
        None,
        ("rpc_status", "list every slot"),
        ("clear_multi_rpc", "wipe all six slots"),
        ("stopactivity", "clear current activity"),
        ("rstatus / remoji", "rotate status text or emoji"),
        ("stopstatus / stopemoji", "stop rotations"),
        ("rpcwatchdog", "watchdog status / stop / start"),
    )

    async def _usage(self, message):
        w = max(len(r[0]) for r in self._MENU if r)
        lines = [f"  {r[0]:<{w}}  {r[1]}" if r else "" for r in self._MENU]
        try:
            await message.channel.send(S._ansi_block(lines))
        except Exception:
            pass