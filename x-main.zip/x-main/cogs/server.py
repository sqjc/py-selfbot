# cogs/server.py | serverinfo, members, channels, roles, ban/kick/mute, setnick, topic, slowmode, icon/banner/name
import base64
import re
import aiohttp
from datetime import timedelta
import modifyself_shim as discord
from . import state as S


def _hj():
    return {"Authorization": S.TOKEN, "Content-Type": "application/json",
            "User-Agent": S.USER_AGENT}


class ServerCog:
    COMMANDS = {"serverinfo", "members", "channels", "roles",
                "ban", "kick", "mute", "unmute",
                "timeout", "mute2", "to", "untimeout", "unmute2", "uto",
                "lock", "lockchannel", "unlock", "unlockchannel",
                "setnick", "topic", "slowmode",
                "servericon", "serverbanner", "servername",
                "emojisteal", "servers", "servercount", "sc", "guildcount"}

    async def handle(self, message, cmd, args):
        client = S.CLIENT

        if cmd == "serverinfo":
            g = message.guild
            if not g:
                return await message.edit(content=S.ui_err("not in a server"))
            owner_display = "?"
            try:
                owner_display = str(getattr(g, "owner", None) or getattr(g, "owner_id", "?"))
            except Exception:
                pass
            member_count = getattr(g, "member_count", 0) or len(getattr(g, "members", []) or [])
            rows = [
                f"  {S.DIM}id{S.RESET}          {g.id}",
                f"  {S.DIM}name{S.RESET}        {g.name}",
                f"  {S.DIM}owner{S.RESET}       {owner_display}",
                f"  {S.DIM}members{S.RESET}     {member_count}",
                f"  {S.DIM}channels{S.RESET}    {len(g.channels)}",
                f"  {S.DIM}roles{S.RESET}       {len(g.roles)}",
                f"  {S.DIM}emojis{S.RESET}      {len(getattr(g, 'emojis', []) or [])}",
            ]
            try:
                rows.append(f"  {S.DIM}created{S.RESET}    {g.created_at.strftime('%Y-%m-%d')}")
            except Exception:
                pass
            await message.edit(content=S.ui_box(g.name, rows))

        elif cmd == "members":
            g = message.guild
            if not g:
                return await message.edit(content=S.ui_err("not in a server"))
            n = int(args[1]) if len(args) > 1 and args[1].isdigit() else 20
            rows = [f"  {S.GREY}•{S.RESET} {m.display_name}  {S.DIM}({m.id}){S.RESET}"
                    for m in list(g.members)[:n]]
            await message.edit(content=S._paginate("members", g.name, rows))

        elif cmd == "channels":
            g = message.guild
            if not g:
                return await message.edit(content=S.ui_err("not in a server"))
            rows = [f"  {S.GREY}•{S.RESET} #{ch.name}  {S.DIM}({ch.id}){S.RESET}"
                    for ch in g.channels]
            await message.edit(content=S._paginate("channels", g.name, rows))

        elif cmd == "roles":
            g = message.guild
            if not g:
                return await message.edit(content=S.ui_err("not in a server"))
            rows = [f"  {S.GREY}•{S.RESET} {r.name}  {S.DIM}({r.id}){S.RESET}"
                    for r in g.roles]
            await message.edit(content=S._paginate("roles", g.name, rows))

        elif cmd in ("ban", "kick", "mute", "unmute"):
            g = message.guild
            if not g or len(args) < 2:
                return await message.edit(content=S.ui_err(f"usage: {cmd} <user_id>"))
            uid = S._parse_uid_str(args[1])
            if uid is None:
                return await message.edit(content=S.ui_err(f"usage: {cmd} <user_id>"))
            try:
                if cmd == "ban":
                    await g.ban(int(uid))
                elif cmd == "kick":
                    await g.kick(int(uid))
                else:
                    member = g.get_member(int(uid))
                    if member is None:
                        return await message.edit(content=S.ui_err(f"user {uid} not in cache"))
                    if cmd == "mute":
                        until = discord.utils.utcnow() + timedelta(minutes=10)
                        await member.timeout(until)
                    else:
                        await member.timeout(None)
                await message.edit(content=S.ui_ok(f"{cmd} → {uid}"))
            except Exception as e:
                await message.edit(content=S.ui_err(str(e)))

        elif cmd in ("timeout", "mute2", "to", "untimeout", "unmute2", "uto"):
            g = message.guild
            if not g or len(args) < 2:
                return await message.edit(content=S.ui_err(f"usage: {cmd} <user_id> [minutes]"))
            uid = S._parse_uid_str(args[1])
            if uid is None:
                return await message.edit(content=S.ui_err(
                    f"`{args[1]}` is not a user — pass a user ID or @mention"))
            member = g.get_member(int(uid))
            if member is None:
                return await message.edit(content=S.ui_err(f"user {uid} not in cache"))
            clear = cmd in ("untimeout", "unmute2", "uto")
            minutes = int(args[2]) if len(args) > 2 and args[2].isdigit() else 10
            try:
                await member.timeout(None if clear else
                                     discord.utils.utcnow() + timedelta(minutes=minutes))
                await message.edit(content=S.ui_ok(
                    f"timeout cleared for {uid}" if clear else f"timed out {uid} for {minutes}m"))
            except Exception as e:
                await message.edit(content=S.ui_err(str(e)))

        elif cmd in ("lock", "lockchannel", "unlock", "unlockchannel"):
            if not message.guild:
                return await message.edit(content=S.ui_err("not in a server"))
            locked = cmd.startswith("lock")
            try:
                await message.channel.set_permissions(
                    message.guild.id, send_messages=False if locked else None)
                await message.edit(content=S.ui_ok(
                    f"{'locked' if locked else 'unlocked'} #{getattr(message.channel, 'name', '?')}"))
            except Exception as e:
                await message.edit(content=S.ui_err(str(e)))

        elif cmd in ("servers", "servercount", "sc", "guildcount"):
            guilds = list(getattr(client, "guilds", []) or [])
            if cmd != "servers":
                return await message.edit(content=S.ui_box("server count", [
                    f"  {S.DIM}guilds{S.RESET}  {len(guilds)}"]))
            rows = [f"  {S.GREY}•{S.RESET} {g.name}  {S.DIM}({g.id}){S.RESET}" for g in guilds]
            await message.edit(content=S._paginate("servers", f"{len(guilds)} guilds", rows)
                                        if rows else S.ui_info("no guilds"))

        elif cmd == "emojisteal":
            if not message.guild or len(args) < 2:
                return await message.edit(content=S.ui_err("usage: emojisteal <emoji | url> [name]"))
            raw = args[1]
            name = args[2] if len(args) > 2 else None
            match = re.match(r"<(a?):(\w+):(\d+)>", raw)
            if match:
                url = (f"https://cdn.discordapp.com/emojis/{match.group(3)}"
                       f".{'gif' if match.group(1) else 'png'}")
                name = name or match.group(2)
            elif raw.startswith("http"):
                url = raw
            else:
                return await message.edit(content=S.ui_err("usage: emojisteal <emoji | url> [name]"))
            name = (name or url.rsplit("/", 1)[-1].split(".")[0] or "emoji")[:32]
            try:
                async with aiohttp.ClientSession() as s:
                    async with s.get(url, headers={"User-Agent": S.USER_AGENT}) as r:
                        if r.status != 200:
                            return await message.edit(content=S.ui_err(f"cdn returned {r.status}"))
                        data = await r.read()
                        ctype = r.headers.get("Content-Type") or "image/png"
                    async with s.post(
                        f"https://discord.com/api/v9/guilds/{message.guild.id}/emojis",
                        headers=_hj(),
                        json={"name": name,
                              "image": f"data:{ctype};base64,{base64.b64encode(data).decode()}"},
                    ) as r2:
                        ok = r2.status in (200, 201)
                await message.edit(content=S.ui_ok(f"stole :{name}:") if ok
                                          else S.ui_err("failed to add emoji"))
            except Exception as e:
                await message.edit(content=S.ui_err(str(e)))

        elif cmd == "setnick":
            g = message.guild
            if not g or len(args) < 3:
                return await message.edit(content=S.ui_err("usage: setnick <user_id> <nick>"))
            uid = S._parse_uid_str(args[1])
            if uid is None:
                return await message.edit(content=S.ui_err("usage: setnick <user_id> <nick>"))
            try:
                m = g.get_member(int(uid))
                if m is None:
                    return await message.edit(content=S.ui_err(f"user {uid} not in cache"))
                await m.edit(nick=" ".join(args[2:]))

                await message.edit(content=S.ui_ok("nick set"))
            except Exception as e:
                await message.edit(content=S.ui_err(str(e)))

        elif cmd == "topic":
            if not message.guild or len(args) < 2:
                return await message.edit(content=S.ui_err("usage: topic <text>"))
            try:
                await message.channel.edit(topic=" ".join(args[1:]))
                await message.edit(content=S.ui_ok("topic set"))
            except Exception as e:
                await message.edit(content=S.ui_err(str(e)))

        elif cmd == "slowmode":
            if not message.guild or len(args) < 2:
                return await message.edit(content=S.ui_err("usage: slowmode <seconds>"))
            try:
                await message.channel.edit(slowmode_delay=int(args[1]))
                await message.edit(content=S.ui_ok("slowmode set"))
            except Exception as e:
                await message.edit(content=S.ui_err(str(e)))

        elif cmd == "servericon":
            if not message.guild or len(args) < 2:
                return await message.edit(content=S.ui_err("usage: servericon <url>"))
            try:
                async with aiohttp.ClientSession() as s:
                    async with s.get(args[1]) as r: img = await r.read()
                await message.guild.edit(icon=img)
                await message.edit(content=S.ui_ok("icon set"))
            except Exception as e:
                await message.edit(content=S.ui_err(str(e)))

        elif cmd == "serverbanner":
            if not message.guild or len(args) < 2:
                return await message.edit(content=S.ui_err("usage: serverbanner <url>"))
            try:
                async with aiohttp.ClientSession() as s:
                    async with s.get(args[1]) as r: img = await r.read()
                await message.guild.edit(banner=img)
                await message.edit(content=S.ui_ok("banner set"))
            except Exception as e:
                await message.edit(content=S.ui_err(str(e)))

        elif cmd == "servername":
            if not message.guild or len(args) < 2:
                return await message.edit(content=S.ui_err("usage: servername <name>"))
            try:
                await message.guild.edit(name=" ".join(args[1:]))
                await message.edit(content=S.ui_ok("name set"))
            except Exception as e:
                await message.edit(content=S.ui_err(str(e)))