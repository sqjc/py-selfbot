# cogs/db.py | notes, history, command stats, db info/vacuum, history export, clear
import json
import os
import time
from datetime import datetime
import modifyself_shim as discord
from . import state as S


class DbCog:
    COMMANDS = {"note", "history", "stats", "db", "exporthistory", "cleardb"}

    async def handle(self, message, cmd, args):
        try: await message.delete()
        except Exception: pass

        if cmd == "note":
            sub = args[1].lower() if len(args) > 1 else ""
            key = S.uid_arg(args, 2)
            if len(args) > 2 and key is None:
                return await message.channel.send(S.ui_info("usage: note add/list/clear <user_id>"))
            if sub == "add" and len(args) >= 4:
                S.db_note_add(key, " ".join(args[3:]))
                await message.channel.send(S.ui_ok("saved"))
            elif sub == "list" and len(args) >= 3:
                rows = [f"  {S.GREY}•{S.RESET} "
                        f"{datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M')}  {n}"
                        for n, ts in S.db_note_list(key)]
                await message.channel.send(
                    S._paginate("notes", key, rows) if rows else S.ui_info("none"))
            elif sub == "clear" and len(args) >= 3:
                S.db_note_clear(key)
                await message.channel.send(S.ui_ok("cleared"))
            else:
                await message.channel.send(S.ui_info("usage: note add/list/clear"))

        elif cmd == "history":
            sub = args[1].lower() if len(args) > 1 else ""
            key = S.uid_arg(args, 2)
            if len(args) > 2 and key is None:
                return await message.channel.send(S.ui_info("usage: history add/list <user_id>"))
            if sub == "add" and len(args) >= 4:
                S.db_hist_add(key, " ".join(args[3:]))
                await message.channel.send(S.ui_ok("saved"))
            elif sub == "list" and len(args) >= 3:
                rows = [f"  {S.GREY}•{S.RESET} "
                        f"{datetime.fromtimestamp(ts).strftime('%H:%M')}  {e}"
                        for e, ts in S.db_hist_list(key)]
                await message.channel.send(
                    S._paginate("history", key, rows) if rows else S.ui_info("none"))
            else:
                await message.channel.send(S.ui_info("usage: history add/list"))

        elif cmd == "stats":
            if len(args) > 1 and args[1].lower() == "clear":
                S.db_stats_clear()
                return await message.channel.send(S.ui_ok("cleared"))
            rows = [f"  {S.GREY}•{S.RESET} {c}  {S.DIM}{n}{S.RESET}"
                    for c, n in S.db_stats_all()[:100]]
            await message.channel.send(
                S._paginate("stats", "top commands", rows) if rows else S.ui_info("no stats yet"))

        elif cmd == "db":
            sub = args[1].lower() if len(args) > 1 else ""
            if sub == "info":
                size = os.path.getsize(S._db_path) if os.path.exists(S._db_path) else 0
                await message.channel.send(S.ui_box("db", [
                    f"  {S.DIM}path{S.RESET}  {S._db_path}",
                    f"  {S.DIM}size{S.RESET}  {size} bytes"]))
            elif sub == "vacuum":
                S._db.execute("VACUUM"); S._db.commit()
                await message.channel.send(S.ui_ok("vacuumed"))
            else:
                await message.channel.send(S.ui_info("usage: db info/vacuum"))

        elif cmd == "exporthistory":
            try:
                rows = S._db.execute("SELECT user_id, entry, ts FROM history").fetchall()
                os.makedirs("exports", exist_ok=True)
                path = f"exports/history_{int(time.time())}.json"
                with open(path, "w", encoding="utf-8") as f:
                    json.dump([{"user_id": r[0], "entry": r[1], "ts": r[2]} for r in rows],
                              f, indent=2)
                await message.channel.send(S.ui_ok(f"exported {len(rows)} → {path}"), delete_after=8)
            except Exception as e:
                await message.channel.send(S.ui_err(str(e)), delete_after=6)

        elif cmd == "cleardb":
            if len(args) < 2 or args[1].lower() != "confirm":
                return await message.channel.send(S.ui_err(
                    "wipes notes, history and stats — run: cleardb confirm"), delete_after=10)
            try:
                for table in ("notes", "history", "stats"):
                    S._db.execute(f"DELETE FROM {table}")
                S._db.commit()
                S._db.execute("VACUUM"); S._db.commit()
                await message.channel.send(S.ui_ok("database cleared"), delete_after=8)
            except Exception as e:
                await message.channel.send(S.ui_err(str(e)), delete_after=6)