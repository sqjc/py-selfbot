# cogs/tools.py | nitro gen, applybypass, tokeninfo, calculate, fact, fetchlyrics, robuxtax, archivechannel
import base64
import random
import re
import string
import aiohttp
from uuid import uuid4
from datetime import datetime
import modifyself_shim as discord
from . import state as S


def _b64url_int(seg):
    """base64url (unpadded) -> int, or None when it is not a valid numeric id."""
    try:
        raw = base64.urlsafe_b64decode(seg + "=" * (-len(seg) % 4))
        text = raw.decode("utf-8", "strict").strip()
        return int(text) if text.isdigit() else None
    except Exception:
        return None


def _token_created(seg):
    """Second token segment -> 'YYYY-MM-DD HH:MM:SS' UTC, or None."""
    try:
        ts = base64.urlsafe_b64decode(seg + "=" * (-len(seg) % 4))
        if len(ts) < 4:
            return None
        epoch = int.from_bytes(ts[:4], "big")
        return datetime.utcfromtimestamp(
            epoch + 1293840000).strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return None


class ToolsCog:
    COMMANDS = {"nitro", "applybypass", "joinserver", "join", "tokeninfo", "calculate",
                "fact", "fetchlyrics", "robuxtax", "archivechannel",
                "price", "p", "cryptocur",
                "txhistory", "txs", "cryptotx", "setwallet", "wallet",
                "setaddy", "addy"}

    _CRYPTO_IDS = {
        "btc": "bitcoin",
        "bitcoin": "bitcoin",
        "ltc": "litecoin",
        "litecoin": "litecoin",
        "doge": "dogecoin",
        "dogecoin": "dogecoin",
    }

    # symbol -> (blockcypher path, ticker); read-only public explorer, no key
    _CHAINS = {
        "btc": ("btc/main", "BTC"), "bitcoin": ("btc/main", "BTC"),
        "ltc": ("ltc/main", "LTC"), "litecoin": ("ltc/main", "LTC"),
        "doge": ("doge/main", "DOGE"), "dogecoin": ("doge/main", "DOGE"),
    }

    async def _crypto_price(self, message, symbol):
        coin_id = self._CRYPTO_IDS.get(symbol.lower())
        if coin_id is None:
            return await message.edit(content=S.ui_err(
                "unsupported currency; use .cryptocur to list supported symbols"))
        url = "https://api.coingecko.com/api/v3/simple/price"
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    url,
                    params={"ids": coin_id, "vs_currencies": "usd"},
                    timeout=aiohttp.ClientTimeout(total=10),
                ) as response:
                    if response.status != 200:
                        return await message.edit(content=S.ui_err(
                            f"price lookup failed (HTTP {response.status})"))
                    data = await response.json()
            price = data.get(coin_id, {}).get("usd")
            if not isinstance(price, (int, float)):
                return await message.edit(content=S.ui_err("price data unavailable"))
            formatted_price = f"${price:,.8f}".rstrip("0").rstrip(".")
            await message.edit(content=S.ui_box(f"{symbol.upper()} price", [
                f"  {S.DIM}USD{S.RESET}  {formatted_price}",
                f"  {S.DIM}source{S.RESET} CoinGecko",
            ]))
        except Exception:
            await message.edit(content=S.ui_err("price lookup failed"))

    async def _tx_history(self, message, symbol, address, limit):
        chain = self._CHAINS.get(symbol.lower())
        if chain is None:
            return await message.edit(content=S.ui_err("unsupported coin; use BTC/LTC/DOGE"))
        path, ticker = chain
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"https://api.blockcypher.com/v1/{path}/addrs/{address}",
                    params={"limit": limit},
                    timeout=aiohttp.ClientTimeout(total=10),
                ) as response:
                    if response.status != 200:
                        return await message.edit(content=S.ui_err(
                            f"lookup failed (HTTP {response.status})"))
                    data = await response.json()
        except Exception:
            return await message.edit(content=S.ui_err("lookup failed"))
        rows = [f"  {S.DIM}balance{S.RESET}  {(data.get('final_balance') or 0) / 1e8:.8f} {ticker}",
                f"  {S.DIM}txs{S.RESET}      {data.get('final_n_tx') or 0}"]
        for tx in (data.get("txrefs") or [])[:limit]:
            direction = "in " if tx.get("tx_input_n") == -1 else "out"
            rows.append(f"  {S.GREY}{direction}{S.RESET} "
                        f"{(tx.get('value') or 0) / 1e8:.8f} {ticker}  "
                        f"{S.DIM}{str(tx.get('tx_hash', ''))[:16]}{S.RESET}")
        await message.edit(content=S.ui_box(f"{ticker} history", rows))

    async def handle(self, message, cmd, args):
        client = S.CLIENT

        if cmd == "cryptocur":
            return await message.edit(content=S.ui_box("supported currencies", [
                "  BTC  Bitcoin",
                "  LTC  Litecoin",
                "  DOGE Dogecoin",
            ]))

        if cmd in ("txhistory", "txs", "cryptotx"):
            if len(args) < 3:
                return await message.edit(content=S.ui_err(
                    f"usage: {cmd} <BTC|LTC|DOGE> <address> [count]"))
            limit = int(args[3]) if len(args) > 3 and args[3].isdigit() else 5
            return await self._tx_history(message, args[1], args[2], min(limit, 20))

        if cmd in ("wallet", "addy"):
            wallets = (S.load_config() or {}).get("wallets") or {}
            if not wallets:
                return await message.edit(content=S.ui_info(
                    "no address saved — use setwallet <coin> <address>"))
            return await message.edit(content=S.ui_box("wallets", [
                f"  {S.DIM}{coin}{S.RESET}  {addr}" for coin, addr in wallets.items()]))

        if cmd in ("setwallet", "setaddy"):
            if len(args) < 3:
                return await message.edit(content=S.ui_err(f"usage: {cmd} <BTC|LTC|DOGE> <address>"))
            if args[1].lower() not in self._CHAINS:
                return await message.edit(content=S.ui_err("unsupported coin; use BTC/LTC/DOGE"))
            cfg = S.load_config() or {}
            cfg.setdefault("wallets", {})[args[1].upper()] = args[2]
            S.save_config(cfg)
            return await message.edit(content=S.ui_ok(f"{args[1].upper()} address saved"))

        if cmd in ("price", "p"):
            if len(args) < 2:
                return await message.edit(content=S.ui_err("usage: price <BTC|LTC|DOGE>"))
            await self._crypto_price(message, args[1])

        elif cmd == "nitro":
            try: await message.delete()
            except Exception: pass
            code = "".join(random.choices(string.ascii_letters + string.digits, k=16))
            await message.channel.send(f"```\nhttps://discord.gift/{code}\n```")

        elif cmd in ("applybypass", "joinserver", "join"):
            try: await message.delete()
            except Exception: pass
            if len(args) < 2:
                return await message.channel.send(S.ui_err(f"usage: {cmd} <invite>"), delete_after=5)
            invite = args[1].replace("https://discord.gg/", "").replace("discord.gg/", "")
            h = {"Authorization": S.TOKEN, "Content-Type": "application/json",
                 "User-Agent": S.USER_AGENT}
            try:
                async with aiohttp.ClientSession() as s:
                    async with s.get(f"https://discord.com/api/v9/invites/{invite}", headers=h) as r:
                        if r.status != 200:
                            return await message.channel.send(S.ui_err("invalid invite"), delete_after=6)
                        inv = await r.json()
                    guild_id = inv.get("guild", {}).get("id")
                    async with s.post(f"https://discord.com/api/v9/invites/{invite}",
                                      headers=h, json={"session_id": str(uuid4())[:8]}) as r2:
                        if r2.status in (200, 204):
                            await message.channel.send(S.ui_ok("joined"), delete_after=8)
                        elif r2.status == 403 and guild_id:
                            async with s.put(
                                f"https://discord.com/api/v9/guilds/{guild_id}/requests/@me",
                                headers=h, json={"form_fields": []}
                            ) as r3:
                                await message.channel.send(
                                    S.ui_ok("applied") if r3.status in (200, 201, 204)
                                    else S.ui_err(f"failed {r3.status}"),
                                    delete_after=8)
                        else:
                            await message.channel.send(S.ui_err(f"failed {r2.status}"), delete_after=6)
            except Exception as e:
                await message.channel.send(S.ui_err(str(e)), delete_after=6)

        elif cmd == "tokeninfo":
            token = args[1] if len(args) > 1 else ""
            if not token:
                return await message.edit(content=S.ui_err("usage: tokeninfo <token>"))
            parts = token.split(".")
            if len(parts) < 2:
                return await message.edit(content=S.ui_err(
                    "not a token — expected 3 dot-separated parts"))
            uid = _b64url_int(parts[0])
            if uid is None:
                return await message.edit(content=S.ui_err(
                    "could not read the user id segment — token looks truncated"))
            rows = [f"  {S.DIM}user_id{S.RESET}  {uid}"]
            created = _token_created(parts[1])
            if created:
                rows.append(f"  {S.DIM}created{S.RESET}  {created} UTC")
            await message.edit(content=S.ui_box("token info", rows))

        elif cmd == "calculate":
            if len(args) < 2:
                return await message.edit(content=S.ui_err("usage: calculate <expr>"))
            expr = " ".join(args[1:])
            try:
                result = eval(re.sub(r"[^0-9+\-*/(). ]", "", expr))
                await message.edit(content=S.ui_ok(f"{expr} = {result}"))
            except Exception as e:
                await message.edit(content=S.ui_err(str(e)))

        elif cmd == "fact":
            try: await message.delete()
            except Exception: pass
            try:
                async with aiohttp.ClientSession() as s:
                    async with s.get(
                        "https://uselessfacts.jsph.pl/api/v2/facts/random?language=en"
                    ) as r:
                        d = await r.json()
                        await message.channel.send(f"💡 {d.get('text','no fact')}")
            except Exception as e:
                await message.channel.send(S.ui_err(str(e)), delete_after=5)

        elif cmd == "fetchlyrics":
            if len(args) < 2:
                return await message.edit(content=S.ui_err("usage: fetchlyrics <artist - title>"))
            query = " ".join(args[1:])
            try:
                async with aiohttp.ClientSession() as s:
                    async with s.get(
                        f"https://lyrist.vercel.app/api/{query.replace(' - ','/')}"
                    ) as r:
                        if r.status == 200:
                            lyrics = (await r.json()).get("lyrics", "")[:1800]
                            await message.edit(content=f"```\n{lyrics}\n```")
                        else:
                            await message.edit(content=S.ui_err("not found"))
            except Exception as e:
                await message.edit(content=S.ui_err(str(e)))

        elif cmd == "robuxtax":
            if len(args) < 2:
                return await message.edit(content=S.ui_err("usage: robuxtax <amount>"))
            try:
                amount = int(args[1])
                after = int(amount * 0.7)
                fee = amount - after
                await message.edit(content=S.ui_box("roblox fee", [
                    f"  {S.DIM}listed{S.RESET}  {amount:,} R$",
                    f"  {S.DIM}fee{S.RESET}     {fee:,} R$",
                    f"  {S.DIM}you get{S.RESET} {after:,} R$",
                ]))
            except ValueError:
                await message.edit(content=S.ui_err("invalid amount"))

        elif cmd == "archivechannel":
            try: await message.delete()
            except Exception: pass
            ch = (client.get_channel(int(args[1]))
                  if len(args) > 1 and args[1].isdigit() else message.channel)
            if not ch:
                return await message.channel.send(S.ui_err("not found"), delete_after=5)
            count = 0; out = []
            async for msg in ch.history(limit=2000):
                ts = msg.timestamp.strftime('%Y-%m-%d %H:%M:%S') if hasattr(msg.timestamp, 'strftime') else str(msg.timestamp)
                out.append(f"[{ts}] {msg.author}: {msg.content}")
                count += 1
            fname = f"exports/archive_{ch.id}.txt"
            with open(fname, "w", encoding="utf-8") as f:
                f.write("\n".join(reversed(out)))
            await message.channel.send(S.ui_ok(f"archived {count} → {fname}"), delete_after=8)
