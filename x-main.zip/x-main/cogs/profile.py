# cogs/profile.py | setpfp, setbio, setbanner, setdisplayname, setpronouns, setaccent, myprofile, accountbackup
# Uses HeaderSpoofer for proper x-super-properties + handles hcaptcha on PATCH /users/@me
import base64
import json
import os
from datetime import datetime
import aiohttp
import modifyself_shim as discord
from . import state as S
from .profile_ext import _fetch_user

# ─── hcaptcha support (same solver used by quests.py) ──────────────────────
try:
    from hcaptcha_challenger.agent import AgentV, AgentConfig
    _HAS_HCAPTCHA = True
except ImportError:
    _HAS_HCAPTCHA = False
    AgentV = AgentConfig = None

_hcaptcha_agent = None

async def _get_hcaptcha_agent():
    global _hcaptcha_agent
    if _hcaptcha_agent is not None:
        return _hcaptcha_agent
    if not _HAS_HCAPTCHA:
        return None
    try:
        config = AgentConfig(
            DISABLE_ANONYMIZED_TELEMETRY=True,
            user_data_dir=os.path.abspath("data/hcaptcha_profile"),
            HEADLESS=True,
        )
        _hcaptcha_agent = AgentV(config=config)
    except Exception as e:
        print(f"[profile/hcaptcha] agent init failed: {e}")
        _hcaptcha_agent = None
    return _hcaptcha_agent

async def _solve_hcaptcha(sitekey: str, page_url: str, rqdata: str = None):
    agent = await _get_hcaptcha_agent()
    if agent is None:
        return None
    try:
        payload = {"sitekey": sitekey, "url": page_url, "rqdata": rqdata or "", "type": "hsl"}
        resp = await agent.solve(payload)
        if resp is None:
            return None
        if hasattr(resp, "generated_pass_UUID"):
            return resp.generated_pass_UUID
        if hasattr(resp, "token"):
            return resp.token
        if isinstance(resp, dict):
            return resp.get("generated_pass_UUID") or resp.get("token") or resp.get("response")
        if isinstance(resp, str):
            return resp
    except Exception as e:
        print(f"[profile/hcaptcha] solve failed: {e}")
    return None

# ─── spoofed headers via HeaderSpoofer ─────────────────────────────────────
def _profile_headers(extra: dict = None) -> dict:
    """Build headers using HeaderSpoofer for proper x-super-properties."""
    try:
        from modifyself.headers import HeaderSpoofer
        spoofer = HeaderSpoofer(S.TOKEN)
        h = spoofer.get_headers(
            referer="https://discord.com/channels/@me",
            context_location="user_settings",
        )
    except Exception:
        # Fallback to bare headers if HeaderSpoofer can't be loaded
        h = {
            "Authorization": S.TOKEN,
            "Content-Type": "application/json",
            "User-Agent": S.USER_AGENT,
        }
    if extra:
        h.update(extra)
    return h


# clear* names reuse the setters' own clear forms: the literal "remove" or no value
_CLEARS = {
    "clearpfp": ("setpfp", "remove"), "clearav": ("setpfp", "remove"),
    "clearpic": ("setpfp", "remove"),
    "clearbanner": ("setbanner", "remove"), "cb": ("setbanner", "remove"),
    "clearbio": ("setbio", None), "cbio": ("setbio", None),
    "clearpronouns": ("setpronouns", None), "clrp": ("setpronouns", None),
    "clearpron": ("setpronouns", None),
    "cleardisplayname": ("setdisplayname", None), "clrdn": ("setdisplayname", None),
    "cdn": ("setdisplayname", None),
    "cleartheme": ("setaccent", "remove"), "ct": ("setaccent", "remove"),
    "clrtheme": ("setaccent", "remove"),
}


def _parse_accent(value):
    """Accept '#5b8cff', '5b8cff', '0x5b8cff', or an int -> Discord int colour."""
    if value is None or value == "":
        return None
    if isinstance(value, int):
        return value
    s = str(value).strip().lstrip("#")
    if s.lower().startswith("0x"):
        s = s[2:]
    try:
        return int(s, 16)
    except Exception:
        try:
            return int(s)
        except Exception:
            return None


async def _url_or_attachment_to_b64(url_or_val, message):
    """Convert URL, attachment, or raw string to base64 data URI."""
    url = url_or_val.strip() if url_or_val else ""
    if not url and getattr(message, "attachments", None) and len(message.attachments) > 0:
        url = message.attachments[0].url

    if not url:
        return None

    if url.lower() in ("remove", "clear", "none", "delete"):
        return "CLEAR"

    if url.startswith("data:"):
        return url

    async with aiohttp.ClientSession() as session:
        req_headers = {"User-Agent": S.USER_AGENT} if getattr(S, "USER_AGENT", None) else {}
        async with session.get(url, headers=req_headers, timeout=20) as resp:
            if resp.status != 200:
                raise Exception(f"Failed to fetch image (HTTP {resp.status})")
            data = await resp.read()
            ct = resp.headers.get("Content-Type", "")

    if not data:
        raise Exception("Downloaded image file is empty")

    if not ct or not ct.startswith("image/"):
        clean_url = url.split("?")[0]
        ext = clean_url.rsplit(".", 1)[-1].lower() if "." in clean_url else "png"
        ct = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg",
              "gif": "image/gif", "webp": "image/webp"}.get(ext, "image/png")

    b64 = base64.b64encode(data).decode()
    return f"data:{ct};base64,{b64}"


class ProfileCog:
    COMMANDS = {
        "setpfp", "setavatar",
        "setbio", "setabout",
        "setbanner",
        "setdisplayname", "setname", "setdisplay",
        "setpronouns",
        "setaccent", "setcolor", "setcolour",
        "clearpfp", "clearav", "clearpic",
        "clearbanner", "cb",
        "clearbio", "cbio",
        "clearpronouns", "clrp", "clearpron",
        "cleardisplayname", "clrdn", "cdn",
        "cleartheme", "ct", "clrtheme",
        "clearall", "resetprofile", "nukeprofile",
        "steal",
        "clone", "copyprofile", "cp2",
        "myprofile", "profile",
        "accountbackup"
    }

    async def _patch_user_me(self, payload: dict):
        """PATCH /users/@me with spoofed headers + hcaptcha retry if Discord challenges."""
        url = "https://discord.com/api/v9/users/@me"
        h = _profile_headers()
        async with aiohttp.ClientSession() as session:
            # First attempt
            async with session.patch(url, headers=h, json=payload) as r:
                status = r.status
                text = await r.text()

            if status in (200, 204):
                try:
                    return True, json.loads(text)
                except Exception:
                    return True, {}

            # Try to parse error body
            try:
                err_json = json.loads(text)
            except Exception:
                err_json = {}

            # --- Captcha challenge ---
            if status == 400 and err_json.get("captcha_sitekey"):
                sitekey  = err_json.get("captcha_sitekey", "")
                rqdata   = err_json.get("captcha_rqdata", "")
                rqtoken  = err_json.get("captcha_rqtoken", "")
                page_url = "https://discord.com/channels/@me"

                captcha_token = await _solve_hcaptcha(sitekey, page_url, rqdata)
                if not captcha_token:
                    return False, (
                        "Discord requires hcaptcha to change this field — "
                        "hcaptcha_challenger is not installed or solve failed. "
                        "Install it: pip install hcaptcha-challenger"
                    )

                retry_headers = _profile_headers({
                    "x-captcha-key":     captcha_token,
                    "x-captcha-rqtoken": rqtoken,
                })
                async with session.patch(
                    url,
                    headers=retry_headers,
                    json={**payload, "captcha_key": captcha_token, "captcha_rqtoken": rqtoken},
                ) as r2:
                    status2 = r2.status
                    text2   = await r2.text()

                if status2 in (200, 204):
                    try:
                        return True, json.loads(text2)
                    except Exception:
                        return True, {}
                try:
                    err2 = json.loads(text2)
                    msg2 = err2.get("message") or text2
                except Exception:
                    msg2 = text2
                return False, f"HTTP {status2} (after captcha solve): {msg2}"

            msg = err_json.get("message") or text
            return False, f"HTTP {status}: {msg}"

    async def _patch_user_profile(self, payload: dict):
        """PATCH /users/@me/profile with spoofed headers."""
        url = "https://discord.com/api/v9/users/@me/profile"
        h = _profile_headers()
        async with aiohttp.ClientSession() as session:
            async with session.patch(url, headers=h, json=payload) as r:
                status = r.status
                text   = await r.text()

        if status in (200, 204):
            try:
                return True, json.loads(text)
            except Exception:
                return True, {}

        try:
            err_json = json.loads(text)
            msg = err_json.get("message") or text
        except Exception:
            msg = text
        return False, f"HTTP {status}: {msg}"

    _CDN = {"avatar": "https://cdn.discordapp.com/avatars/{uid}/{h}.{ext}?size=512",
            "banner": "https://cdn.discordapp.com/banners/{uid}/{h}.{ext}?size=600"}

    async def _copy_profile(self, message, uid, u):
        """Copy the public profile fields of `u` onto this account."""
        payload = {}
        for field, tmpl in self._CDN.items():
            h = u.get(field)
            if not h:
                continue
            ext = "gif" if str(h).startswith("a_") else "webp"
            payload[field] = await _url_or_attachment_to_b64(
                tmpl.format(uid=uid, h=h, ext=ext), message)
        if payload:
            ok, res = await self._patch_user_me(payload)
            if not ok:
                return await message.edit(content=S.ui_err(f"failed: {res}"))

        prof = {}
        try:
            async with aiohttp.ClientSession() as s:
                async with s.get(f"https://discord.com/api/v9/users/{uid}/profile",
                                 headers=_profile_headers()) as r:
                    if r.status == 200:
                        prof = (await r.json()).get("user_profile") or {}
        except Exception:
            pass

        ok, res = await self._patch_user_profile({
            "bio": (prof.get("bio") or "")[:190],
            "pronouns": (prof.get("pronouns") or "")[:40],
        })
        await message.edit(content=S.ui_ok(f"copied profile from {u.get('username', '?')}")
                                  if ok else S.ui_err(f"failed: {res}"))

    async def handle(self, message, cmd, args):
        client = S.CLIENT

        if cmd in _CLEARS:
            target, value = _CLEARS[cmd]
            args = [target] if value is None else [target, value]
            cmd = target

        if cmd in ("setpfp", "setavatar"):
            raw_val = args[1] if len(args) > 1 else ""
            if not raw_val and not (getattr(message, "attachments", None) and len(message.attachments) > 0):
                return await message.edit(content=S.ui_err("usage: setpfp <url | attach image | remove>"))
            try:
                uri = await _url_or_attachment_to_b64(raw_val, message)
                avatar_val = None if uri in (None, "CLEAR") else uri
                ok, res = await self._patch_user_me({"avatar": avatar_val})
                if ok:
                    await message.edit(content=S.ui_ok("avatar updated" if avatar_val else "avatar cleared"))
                else:
                    await message.edit(content=S.ui_err(f"failed to update avatar: {res}"))
            except Exception as e:
                await message.edit(content=S.ui_err(str(e)))

        elif cmd == "setbanner":
            raw_val = args[1] if len(args) > 1 else ""
            if not raw_val and not (getattr(message, "attachments", None) and len(message.attachments) > 0):
                return await message.edit(content=S.ui_err("usage: setbanner <url | attach image | remove>"))
            try:
                uri = await _url_or_attachment_to_b64(raw_val, message)
                banner_val = None if uri in (None, "CLEAR") else uri
                ok, res = await self._patch_user_me({"banner": banner_val})
                if ok:
                    await message.edit(content=S.ui_ok("banner updated" if banner_val else "banner cleared"))
                else:
                    await message.edit(content=S.ui_err(f"failed to update banner: {res}"))
            except Exception as e:
                await message.edit(content=S.ui_err(str(e)))

        elif cmd in ("setdisplayname", "setname", "setdisplay"):
            name = " ".join(args[1:]) if len(args) > 1 else ""
            try:
                ok, res = await self._patch_user_me({"global_name": name[:32] if name else None})
                if ok:
                    await message.edit(content=S.ui_ok(f"display name set to: {name}" if name else "display name reset"))
                else:
                    await message.edit(content=S.ui_err(f"failed to set display name: {res}"))
            except Exception as e:
                await message.edit(content=S.ui_err(str(e)))

        elif cmd in ("setaccent", "setcolor", "setcolour"):
            val = args[1] if len(args) > 1 else ""
            if not val:
                return await message.edit(content=S.ui_err("usage: setaccent <#hex | 0xhex | int | remove>"))
            if val.lower() in ("remove", "clear", "none", "reset"):
                accent_val = None
            else:
                accent_val = _parse_accent(val)
                if accent_val is None:
                    return await message.edit(content=S.ui_err("invalid accent colour (use hex e.g. #5b8cff)"))
            try:
                ok, res = await self._patch_user_me({"accent_color": accent_val})
                if ok:
                    hex_str = f"#{accent_val:06x}" if isinstance(accent_val, int) else "cleared"
                    await message.edit(content=S.ui_ok(f"accent colour updated ({hex_str})"))
                else:
                    await message.edit(content=S.ui_err(f"failed to set accent colour: {res}"))
            except Exception as e:
                await message.edit(content=S.ui_err(str(e)))

        elif cmd in ("setbio", "setabout"):
            bio = " ".join(args[1:]) if len(args) > 1 else ""
            try:
                ok, res = await self._patch_user_profile({"bio": bio[:190]})
                if ok:
                    await message.edit(content=S.ui_ok("bio updated"))
                else:
                    await message.edit(content=S.ui_err(f"failed to update bio: {res}"))
            except Exception as e:
                await message.edit(content=S.ui_err(str(e)))

        elif cmd == "setpronouns":
            pronouns = " ".join(args[1:]) if len(args) > 1 else ""
            try:
                ok, res = await self._patch_user_profile({"pronouns": pronouns[:40]})
                if ok:
                    await message.edit(content=S.ui_ok("pronouns updated"))
                else:
                    await message.edit(content=S.ui_err(f"failed to update pronouns: {res}"))
            except Exception as e:
                await message.edit(content=S.ui_err(str(e)))

        elif cmd in ("steal", "clone", "copyprofile", "cp2"):
            uid = S.uid_arg(args, 1, message.author.id)
            if uid is None:
                return await message.edit(content=S.ui_err(f"usage: {cmd} <user_id>"))
            u, status = await _fetch_user(uid)
            if not u:
                return await message.edit(content=S.ui_err(f"not found ({status})"))
            try:
                await self._copy_profile(message, uid, u)
            except Exception as e:
                await message.edit(content=S.ui_err(str(e)))

        elif cmd in ("clearall", "resetprofile", "nukeprofile"):
            try:
                ok, res = await self._patch_user_me({"avatar": None, "banner": None,
                                                     "accent_color": None,
                                                     "global_name": None})
                if ok:
                    ok, res = await self._patch_user_profile({"bio": "", "pronouns": ""})
                await message.edit(content=S.ui_ok("profile reset") if ok
                                          else S.ui_err(f"failed: {res}"))
            except Exception as e:
                await message.edit(content=S.ui_err(str(e)))

        elif cmd == "profile" and len(args) > 1 and args[1].lower() in ("save", "load", "list", "delete"):
            from .settings import SettingsCog
            return await SettingsCog()._profile(message, args)

        elif cmd in ("myprofile", "profile"):
            h = {"Authorization": S.TOKEN, "User-Agent": S.USER_AGENT}
            try:
                async with aiohttp.ClientSession() as s:
                    async with s.get("https://discord.com/api/v9/users/@me", headers=h) as r:
                        if r.status != 200:
                            return await message.edit(content=S.ui_err("failed to fetch user info"))
                        u = await r.json()
                    async with s.get(f"https://discord.com/api/v9/users/{u.get('id')}/profile", headers=h) as r2:
                        prof = (await r2.json()).get("user_profile", {}) if r2.status == 200 else {}

                uid = u.get("id")
                pfp = (f"https://cdn.discordapp.com/avatars/{uid}/{u.get('avatar')}.webp?size=256"
                       if u.get("avatar") else "none")
                banner = (f"https://cdn.discordapp.com/banners/{uid}/{u.get('banner')}.webp?size=512"
                          if u.get("banner") else "none")
                acc = u.get("accent_color")
                accent_hex = f"#{acc:06x}" if isinstance(acc, int) else "none"

                await message.edit(content=S.ui_box("my profile", [
                    f"  {S.DIM}username{S.RESET}     {u.get('username')}",
                    f"  {S.DIM}display name{S.RESET} {u.get('global_name') or '-'}",
                    f"  {S.DIM}id{S.RESET}           {uid}",
                    f"  {S.DIM}bio{S.RESET}          {prof.get('bio') or '-'}",
                    f"  {S.DIM}pronouns{S.RESET}     {prof.get('pronouns') or '-'}",
                    f"  {S.DIM}accent{S.RESET}       {accent_hex}",
                    f"  {S.DIM}avatar{S.RESET}       {pfp}",
                    f"  {S.DIM}banner{S.RESET}       {banner}",
                    f"  {S.DIM}email{S.RESET}        {u.get('email','?')}",
                    f"  {S.DIM}phone{S.RESET}        {u.get('phone','?')}",
                    f"  {S.DIM}nitro{S.RESET}        {'yes' if u.get('premium_type') else 'no'}",
                ]))
            except Exception as e:
                await message.edit(content=S.ui_err(str(e)))

        elif cmd == "accountbackup":
            try: await message.delete()
            except Exception: pass
            h = {"Authorization": S.TOKEN, "User-Agent": S.USER_AGENT}
            async with aiohttp.ClientSession() as s:
                async with s.get("https://discord.com/api/v9/users/@me", headers=h) as r:
                    profile = await r.json() if r.status == 200 else {}
                async with s.get("https://discord.com/api/v9/users/@me/relationships",
                                 headers=h) as r:
                    rels = await r.json() if r.status == 200 else []
            backup = {"profile": profile, "relationships": rels,
                      "guilds": [{"id": str(g.id), "name": g.name} for g in client.guilds],
                      "timestamp": datetime.now().isoformat()}
            os.makedirs("backups", exist_ok=True)
            fname = f"backups/account_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            with open(fname, "w") as f:
                json.dump(backup, f, indent=2)
            await message.channel.send(S.ui_ok(f"backed up → {fname}"), delete_after=8)