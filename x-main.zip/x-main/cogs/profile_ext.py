# cogs/profile_ext.py | avatar/banner download, profile history, user notes, personal block/whitelist/ignore
import os
import json
import time
import aiohttp
from datetime import datetime
import modifyself_shim as discord
from . import state as S


def _av_url(uid, u):
    if not u.get("avatar"): return None
    ext = "gif" if str(u["avatar"]).startswith("a_") else "png"
    return f"https://cdn.discordapp.com/avatars/{uid}/{u['avatar']}.{ext}?size=1024"


def _bn_url(uid, u):
    if not u.get("banner"): return None
    ext = "gif" if str(u["banner"]).startswith("a_") else "png"
    return f"https://cdn.discordapp.com/banners/{uid}/{u['banner']}.{ext}?size=1024"


_spoofer = None


def _headers():
    """Spoofed browser headers.

    Bare `Authorization` + `User-Agent` gets 403 on Discord's user-profile
    routes. `cogs/profile.py` already solves this with HeaderSpoofer, so use
    the same construction here and fall back to bare headers if it is
    unavailable.
    """
    global _spoofer
    try:
        from modifyself.headers import HeaderSpoofer
        if _spoofer is None:
            _spoofer = HeaderSpoofer(S.TOKEN)
        return _spoofer.get_headers(
            referer="https://discord.com/channels/@me",
            context_location="chat_input",
        )
    except Exception:
        return {"Authorization": S.TOKEN, "User-Agent": S.USER_AGENT}


def _ext_for(ctype, url):
    """Pick the extension from what the CDN actually served."""
    c = (ctype or "").lower()
    for key, ext in (("image/gif", "gif"), ("image/webp", "webp"),
                     ("image/jpeg", "jpg"), ("image/png", "png")):
        if key in c:
            return ext
    tail = url.split("?", 1)[0].rsplit(".", 1)
    return tail[-1].lower() if len(tail) == 2 else "png"


async def _fetch_user(uid):
    """Resolve a user, preferring the profile endpoint.

    GET /users/{id}/profile carries `user_profile.banner` and is the route
    that works for user tokens; GET /users/{id} omits the banner for
    arbitrary users and is tried as the fallback.
    """
    h = _headers()
    u = None
    status = None
    async with aiohttp.ClientSession() as s:
        try:
            async with s.get(
                f"https://discord.com/api/v9/users/{uid}/profile", headers=h
            ) as r:
                status = r.status
                if r.status == 200:
                    p = await r.json()
                    u = dict(p.get("user") or {})
                    up = p.get("user_profile") or {}
                    if up.get("banner") and not u.get("banner"):
                        u["banner"] = up.get("banner")
                    if up.get("bio") is not None:
                        u.setdefault("bio", up.get("bio"))
        except Exception:
            pass
        if u:
            return u, 200
        try:
            async with s.get(f"https://discord.com/api/v9/users/{uid}",
                             headers=h) as r:
                status = r.status
                if r.status == 200:
                    u = await r.json()
        except Exception:
            pass
    return (u or None), (status if status is not None else 0)


async def _download(url, out_dir, uid):
    """Fetch the CDN asset with proper headers and validate what came back."""
    os.makedirs(out_dir, exist_ok=True)
    async with aiohttp.ClientSession() as s:
        async with s.get(url, headers={"User-Agent": S.USER_AGENT}) as r:
            ctype = r.headers.get("Content-Type", "")
            if r.status != 200:
                return None, f"cdn returned {r.status}"
            data = await r.read()
    if not data:
        return None, "empty response from cdn"
    if "text/html" in ctype.lower() or "application/json" in ctype.lower():
        return None, f"cdn served {ctype} instead of an image"
    ext = _ext_for(ctype, url)
    path = os.path.join(out_dir, f"{uid}.{ext}")
    with open(path, "wb") as f:
        f.write(data)
    return path, None


class ProfileExtCog:
    COMMANDS = {"avatardl", "bannerdl", "profilehistory", "usernote",
                "personalblock", "personalunblock", "personalignore",
                "personalunignore", "personalblocklist", "personallist"}

    async def handle(self, message, cmd, args):
        if cmd == "avatardl":
            uid = S.uid_arg(args, 1, message.author.id)
            if uid is None:
                return await message.edit(content=S.ui_err(f"usage: {cmd} [uid]"))
            u, status = await _fetch_user(uid)
            if not u:
                return await message.edit(content=S.ui_err(f"not found ({status})"))
            url = _av_url(uid, u)
            if not url:
                return await message.edit(content=S.ui_info("no avatar"))
            path, err = await _download(url, os.path.join("exports", "avatars"), uid)
            if err:
                return await message.edit(content=S.ui_err(err))
            await message.edit(content=S.ui_ok(f"saved {path}"))

        elif cmd == "bannerdl":
            uid = S.uid_arg(args, 1, message.author.id)
            if uid is None:
                return await message.edit(content=S.ui_err(f"usage: {cmd} [uid]"))
            u, status = await _fetch_user(uid)
            if not u:
                return await message.edit(content=S.ui_err(f"not found ({status})"))
            url = _bn_url(uid, u)
            if not url:
                return await message.edit(content=S.ui_info(
                    "no banner (or not visible to your account)"))
            path, err = await _download(url, os.path.join("exports", "banners"), uid)
            if err:
                return await message.edit(content=S.ui_err(err))
            await message.edit(content=S.ui_ok(f"saved {path}"))

        elif cmd == "profilehistory":
            uid = S.uid_arg(args, 1, message.author.id)
            if uid is None:
                return await message.edit(content=S.ui_err(f"usage: {cmd} [uid]"))
            hist = S.profile_history.get(uid, [])
            if not hist:
                # snapshot now
                u, _st = await _fetch_user(uid)
                if u:
                    S.profile_history.setdefault(uid, []).append({
                        "ts": time.time(),
                        "username": u.get("username"),
                        "global_name": u.get("global_name"),
                        "avatar": u.get("avatar"),
                        "banner": u.get("banner"),
                    })
                hist = S.profile_history.get(uid, [])
            if not hist:
                return await message.edit(content=S.ui_info("no history"))
            rows = []
            for e in hist[-30:]:
                rows.append(f"  {S.GREY}•{S.RESET} {e['username']}  "
                            f"{S.DIM}av:{'y' if e.get('avatar') else 'n'} "
                            f"bn:{'y' if e.get('banner') else 'n'} "
                            f"{datetime.fromtimestamp(e['ts']).strftime('%m-%d %H:%M')}{S.RESET}")
            await message.edit(content=S._paginate("profile history", f"user {uid}", rows))

        elif cmd == "usernote":
            if len(args) < 3:
                return await message.edit(content=S.ui_err(
                    "usage: usernote add <uid> <text> | list <uid> | clear <uid>"))
            sub = args[1].lower()
            key = S.uid_arg(args, 2)
            if key is None:
                return await message.edit(content=S.ui_err(
                    "usage: usernote add <uid> <text> | list <uid> | clear <uid>"))
            if sub == "add" and len(args) >= 4:
                S.db_note_add(key, " ".join(args[3:]))
                return await message.edit(content=S.ui_ok("saved"))
            if sub == "list" and len(args) >= 3:
                rows = [f"  {S.GREY}•{S.RESET} "
                        f"{datetime.fromtimestamp(ts).strftime('%m-%d %H:%M')}  {n}"
                        for n, ts in S.db_note_list(key)]
                return await message.edit(content=S._paginate("notes", key, rows)
                                                    if rows else S.ui_info("none"))
            if sub == "clear" and len(args) >= 3:
                S.db_note_clear(key)
                return await message.edit(content=S.ui_ok("cleared"))
            await message.edit(content=S.ui_info("usage: usernote add/list/clear"))

        elif cmd in ("personalblock", "personalignore"):
            uid = S.uid_arg(args, 1)
            if uid is None:
                return await message.edit(content=S.ui_err(f"usage: {cmd} <uid>"))
            if cmd == "personalblock":
                S.personal_blocklist.add(uid)
            else:
                S.personal_ignore.add(uid)
            await message.edit(content=S.ui_ok(f"{cmd} {uid}"))

        elif cmd in ("personalunblock", "personalunignore"):
            uid = S.uid_arg(args, 1)
            if uid is None:
                return await message.edit(content=S.ui_err(f"usage: {cmd} <uid>"))
            if cmd == "personalunblock":
                S.personal_blocklist.discard(uid)
            else:
                S.personal_ignore.discard(uid)
            await message.edit(content=S.ui_ok("removed"))

        elif cmd == "personalblocklist":
            rows = [f"  {S.GREY}•{S.RESET} <@{u}>" for u in sorted(S.personal_blocklist)]
            await message.edit(content=S._paginate("personal blocklist", "", rows)
                                        if rows else S.ui_info("empty"))

        elif cmd == "personallist":
            rows = [
                f"  {S.DIM}block{S.RESET}  {len(S.personal_blocklist)}",
                f"  {S.DIM}ignore{S.RESET} {len(S.personal_ignore)}",
                "",
                *[f"  {S.GREY}•{S.RESET} <@{u}>  {S.DIM}block{S.RESET}" for u in sorted(S.personal_blocklist)],
                *[f"  {S.GREY}•{S.RESET} <@{u}>  {S.DIM}ignore{S.RESET}" for u in sorted(S.personal_ignore)],
            ]
            await message.edit(content=S._ansi_block(rows))