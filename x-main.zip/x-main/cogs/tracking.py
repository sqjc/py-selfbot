# cogs/tracking.py | track/untrack/tracklist — message + profile history per user
from datetime import datetime
import modifyself_shim as discord
from . import state as S


class TrackingCog:
    COMMANDS = {"track", "untrack", "tracklist"}

    async def handle(self, message, cmd, args):
        if cmd == "track":
            uid = S.uid_arg(args, 1)
            if uid is None:
                return await message.edit(content=S.ui_err("usage: track <user_id>"))
            S._tracked_users.add(uid)
            await message.edit(content=S.ui_ok(f"tracking <@{uid}>"))

        elif cmd == "untrack":
            uid = S.uid_arg(args, 1)
            if uid is None:
                return await message.edit(content=S.ui_err("usage: untrack <user_id>"))
            S._tracked_users.discard(uid)
            S._tracking.pop(uid, None)
            await message.edit(content=S.ui_ok("stopped"))

        elif cmd == "tracklist":
            if not S._tracked_users:
                return await message.edit(content=S.ui_info("not tracking anyone"))
            rows = [f"  {S.GREY}•{S.RESET} <@{uid}>  "
                    f"{S.DIM}({len(S._tracking.get(uid,[]))} msgs){S.RESET}"
                    for uid in S._tracked_users]
            await message.edit(content=S._paginate("tracking", "", rows))