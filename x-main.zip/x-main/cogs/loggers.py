# cogs/loggers.py | message / deleted / edited / reaction / mention / dm / join / leave loggers
#                   + centralized Components V2 webhook audit logger (monochrome)
import asyncio
import hashlib
import inspect
import json
import os
import re
import sys
import time
import uuid
from collections import deque
from datetime import datetime
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit
import aiohttp
import modifyself_shim as discord
from . import state as S


# ─────────────────────────────────────────────
# Components V2 webhook audit logger
# ─────────────────────────────────────────────
# Discord message flag: a message carrying Components V2 must set this bit and
# must NOT carry a plain `content` field.
_IS_COMPONENTS_V2 = 1 << 15
_MAX_TEXT = 3900        # per text-display budget
_MAX_QUEUE = 200        # bounded so a dead webhook cannot eat memory
_MAX_PARKED = 200       # held while no webhook is configured yet
_MAX_DEAD = 100         # permanently-failed records kept for inspection
_MAX_ATTEMPTS = 4
_DEDUPE_WINDOW = 2.0    # drops accidental double-fires of the same record
_RETRY_CAP = 30.0       # never sleep longer than this on a 429
_POLL_IDLE = 2.0        # how often the worker re-checks for a webhook

# Status -> plain word. No colour anywhere in this payload.
_STATUS_LABEL = {"ok": "OK", "err": "ERROR", "info": "INFO", "warn": "WARNING"}

_audit_queue: "asyncio.Queue" = None
_audit_task = None
_session = None

_parked: "deque" = deque()   # no webhook configured yet — held, NOT discarded
_dead: "deque" = deque()     # gave up after retries — kept for inspection

_seen: dict = {}             # record signature -> last emit time
_stats = {"queued": 0, "sent": 0, "parked": 0, "failed": 0, "dropped": 0,
          "deduped": 0, "last_error": None, "last_ok": None, "last_attempt": None}

_SPILL_PATH = os.path.join("logs", "audit_spill.jsonl")
_SESSION_PATH = os.path.join("logs", "audit_session.json")
_SESSION_ID = os.environ.get("WILT_SESSION_ID") or uuid.uuid4().hex
_PROCESS_STARTED = time.time()
_THUMBNAIL_URL = "https://i.pinimg.com/736x/60/4f/45/604f4534c606f0dbd6d5a10daa004433.jpg"

def _webhook_id(url):
    m = re.search(r"/webhooks/(\d+)/", url or "")
    return m.group(1) if m else None

def _webhook_url():
    """Reuse the existing .setwebhook destination; env var is the fallback."""
    u = None
    try:
        u = (S.meta or {}).get("webhook")
    except Exception:
        u = None
    if not u:
        u = os.environ.get("LOG_WEBHOOK_URL") or None
    return u or None


def _components_webhook_url(url):
    """Enable Components V2 when executing a Discord webhook.

    Discord silently ignores component trees sent to ordinary webhooks unless
    this query parameter is present.  Since Components V2 messages cannot
    include a normal ``content`` field, an ignored tree is rejected as an
    empty message (HTTP 400 / code 50006).
    """
    try:
        parts = urlsplit(url)
        query = dict(parse_qsl(parts.query, keep_blank_values=True))
        query["with_components"] = "true"
        return urlunsplit((parts.scheme, parts.netloc, parts.path,
                           urlencode(query), parts.fragment))
    except Exception:
        # Let the existing transport report malformed destinations normally.
        return url


def _redact(text):
    """Never ship tokens or webhook URLs into a log sink."""
    try:
        return S.redact_secrets(text)
    except Exception:
        return str(text) if text is not None else ""


def _now():
    """Local time with an explicit UTC offset so timestamps are unambiguous."""
    return datetime.now().astimezone().strftime("%Y-%m-%d %H:%M:%S %z")


def _warn(msg):
    try:
        print(f"[wilt] {msg}")
    except Exception:
        pass


def _caller_source():
    """Best-effort module name without making callers repeat boilerplate."""
    try:
        for frame in inspect.stack()[2:]:
            module = frame.frame.f_globals.get("__name__", "")
            if module and module != __name__:
                return module
    except Exception:
        pass
    return "unknown"


# ── payload construction (monochrome) ───────────────────────────────────────

def _body_lines(title, fields, status, stamp):
    """A short, human-readable summary for the thumbnail Section."""
    lab = _STATUS_LABEL.get(status, "INFO").title()
    event = _redact(title).replace("_", " ").strip().title()
    lines = [f"**{event}**", f"{lab} · {stamp}"]
    rows = [(_redact(str(l)), _redact("" if v is None else v))
            for l, v in (fields or [])]
    if rows:
        lines.append("")
        for l, v in rows:
            lines.append(f"**{l.replace('_', ' ').title()}:** {v}")
    return lines


def _chunks(lines, budget=_MAX_TEXT):
    """Split lines into groups that each fit inside one text display."""
    out, cur, size = [], [], 0
    for ln in lines:
        # A stack trace or API error may arrive as one very long line. Split
        # it before accounting for it so Discord's 4,000-char text-display
        # limit is always respected.
        while len(ln) > budget:
            if cur:
                out.append(cur)
                cur, size = [], 0
            out.append([ln[:budget]])
            ln = ln[budget:]
        n = len(ln) + 1
        if cur and size + n > budget:
            out.append(cur)
            cur, size = [], 0
        cur.append(ln)
        size += n
    if cur:
        out.append(cur)
    return out or [[]]


def build_payloads(title, fields, status="info", accent=None, ts=None,
                   thumbnail_url=None):
    """
    Compose a monochrome Components V2 message.

    title  – event name
    fields – list of (label, value) pairs, already caller-formatted
    status – 'ok' | 'err' | 'info' | 'warn'
    accent – accepted for call-site compatibility, deliberately ignored:
             containers carry no colour.
    ts     – pre-rendered timestamp string (used when re-sending)
    """
    status = status if status in _STATUS_LABEL else "info"
    stamp = ts or _now()
    chunks = _chunks(_body_lines(title, fields, status, stamp))
    payloads = []
    for number, chunk in enumerate(chunks, 1):
        heading = "### Bot activity" + (f" · {number}/{len(chunks)}" if len(chunks) > 1 else "")
        # Native Components V2: Container (17), Section (9), Text Display
        # (10), Thumbnail (11), and Separator (14).  Every visible text item
        # is inside a thumbnail Section; the image is purely decorative.
        # No content, embeds, colour, or accent field is included.
        payloads.append({"flags": _IS_COMPONENTS_V2,
                         "allowed_mentions": {"parse": []},
                         "components": [{"type": 17, "components": [
                             {"type": 14, "divider": True, "spacing": 1},
                             {"type": 9, "components": [
                                 {"type": 10, "content": heading},
                                 {"type": 10, "content": "\n".join(chunk)},
                             ], "accessory": {"type": 11, "media": {
                                 "url": thumbnail_url or _THUMBNAIL_URL}}},
                             {"type": 14, "divider": True, "spacing": 1},
                         ]}]})
    return payloads


def build_payload(title, fields, status="info", accent=None, ts=None,
                  thumbnail_url=None):
    """Compatibility helper returning the first native Components V2 message."""
    return build_payloads(title, fields, status, accent, ts, thumbnail_url)[0]


# ── queue plumbing ──────────────────────────────────────────────────────────

def _signature(title, fields, status):
    try:
        body = json.dumps([str(title), sorted(str(p) for p in (fields or [])), str(status)],
                          sort_keys=True)
    except Exception:
        body = f"{title}|{fields}|{status}"
    return hashlib.sha1(body.encode("utf-8", "replace")).hexdigest()


def _note_seen(sig):
    """Return True when this record is a duplicate inside the window."""
    now = time.time()
    last = _seen.get(sig)
    if last is not None and now - last < _DEDUPE_WINDOW:
        return True
    _seen[sig] = now
    if len(_seen) > 500:
        cutoff = now - 60.0
        for k in [k for k, v in _seen.items() if v < cutoff]:
            _seen.pop(k, None)
    return False


def _spill(items):
    """Persist undelivered records so a restart does not lose them."""
    try:
        if not items:
            return
        d = os.path.dirname(_SPILL_PATH)
        if d:
            os.makedirs(d, exist_ok=True)
        with open(_SPILL_PATH, "a", encoding="utf-8") as f:
            for it in items:
                f.write(json.dumps(it, ensure_ascii=False, default=str) + "\n")
    except Exception:
        pass


def _recover_spill():
    """Re-queue records spilled by a previous unclean shutdown."""
    global _audit_queue
    try:
        if not os.path.exists(_SPILL_PATH):
            return 0
        with open(_SPILL_PATH, "r", encoding="utf-8") as f:
            lines = f.readlines()
        os.remove(_SPILL_PATH)
        n = 0
        for ln in lines:
            ln = ln.strip()
            if not ln:
                continue
            try:
                it = json.loads(ln)
            except Exception:
                continue
            if isinstance(it, dict) and _audit_queue is not None:
                _audit_queue.put_nowait(it)
                n += 1
        return n
    except Exception:
        return 0


def _drain_queue():
    out = []
    if _audit_queue is None:
        return out
    try:
        while True:
            out.append(_audit_queue.get_nowait())
    except Exception:
        pass
    return out


# ── transport ───────────────────────────────────────────────────────────────

async def _get_session():
    global _session
    if _session is None:
        try:
            _session = aiohttp.ClientSession(
                headers={"User-Agent": S.USER_AGENT},
                timeout=aiohttp.ClientTimeout(total=30),
            )
        except Exception:
            _session = aiohttp.ClientSession()
    return _session


async def _send_all(url, payloads):
    """POST a list of payloads in order. Returns (ok, detail)."""
    url = _components_webhook_url(url)
    last = (False, "nothing to send")
    for payload in payloads:
        last = await _send_one(url, payload)
        if not last[0]:
            return last
    return last


async def _send_one(url, payload):
    """POST one payload. Returns (ok, detail). Retries 429/5xx/network faults."""
    s = await _get_session()
    for attempt in range(_MAX_ATTEMPTS):
        try:
            async with s.post(url, json=payload) as r:
                if r.status in (200, 204):
                    return True, None
                if r.status == 429:
                    try:
                        info = await r.json()
                        wait = float(info.get("retry_after")
                                     or r.headers.get("Retry-After", 1.0))
                    except Exception:
                        try:
                            wait = float(r.headers.get("Retry-After", 1.0))
                        except Exception:
                            wait = 1.0
                    await asyncio.sleep(max(0.5, min(wait, _RETRY_CAP)))
                    continue
                if 400 <= r.status < 500:
                    try:
                        body = (await r.text())[:200]
                    except Exception:
                        body = ""
                    return False, f"HTTP {r.status} {_redact(body)}"
                await asyncio.sleep(min(1.5 * (2 ** attempt), 20.0))
        except asyncio.CancelledError:
            raise
        except Exception as e:
            if attempt == _MAX_ATTEMPTS - 1:
                return False, f"{type(e).__name__}: {_redact(str(e))[:200]}"
            await asyncio.sleep(min(1.5 * (2 ** attempt), 20.0))
    return False, f"gave up after {_MAX_ATTEMPTS} attempts"


def _record_failure(item, detail):
    try:
        if len(_dead) >= _MAX_DEAD:
            _dead.popleft()
        _dead.append({"item": item, "error": detail, "ts": time.time()})
    except Exception:
        pass
    _warn(f"audit delivery FAILED: {item.get('title')} - {detail}")
    # The dead-letter queue is useful in-process; the JSONL spill is the
    # durable fallback that survives a crash or a webhook outage.
    _spill([item])
    try:
        el = S.meta.get("error_log")
        if isinstance(el, list):
            el.append({"ts": time.time(),
                       "msg": f"audit delivery failed: {item.get('title')}: {detail}"})
            del el[:-200]
    except Exception:
        pass


async def _deliver(url, item):
    _stats["last_attempt"] = time.time()
    title = item.get("title")
    fields = item.get("fields")
    status = item.get("status", "info")
    ts = item.get("ts")
    thumbnail_url = item.get("thumbnail_url")
    # A webhook that cannot accept Components V2 is retained locally as a
    # delivery failure; it is never downgraded to a legacy/plain message.
    ok, detail = await _send_all(
        url, build_payloads(title, fields, status, ts=ts,
                            thumbnail_url=thumbnail_url))

    if ok:
        _stats["sent"] += 1
        _stats["last_ok"] = time.time()
    else:
        _stats["failed"] += 1
        _stats["last_error"] = detail
        _record_failure(item, detail)
    try:
        _audit_queue.task_done()
    except Exception:
        pass


def _park_now(item):
    """Hold an event until a webhook is configured. Never discard silently."""
    _stats["parked"] += 1
    try:
        if len(_parked) >= _MAX_PARKED:
            _spill([_parked.popleft()])
            _stats["dropped"] += 1
        _parked.append(item)
    except Exception:
        _stats["dropped"] += 1
        return
    if _stats["parked"] == 1:
        _warn("audit logger: no webhook configured - events are being held. "
              "Run 'setwebhook <url>' to start delivering.")


async def _flush_parked():
    """Deliver held events once a destination exists (FIFO)."""
    while _parked:
        url = _webhook_url()
        if not url:
            return
        try:
            item = _parked.popleft()
        except Exception:
            return
        await _deliver(url, item)


async def _audit_worker():
    while True:
        try:
            item = await asyncio.wait_for(_audit_queue.get(), timeout=_POLL_IDLE)
        except asyncio.TimeoutError:
            # idle: retry anything held now that a webhook may exist
            try:
                await _flush_parked()
            except Exception:
                pass
            continue
        except asyncio.CancelledError:
            raise
        except Exception:
            await asyncio.sleep(0.5)
            continue

        url = _webhook_url()
        if not url:
            _park_now(item)
            continue
        try:
            await _flush_parked()
        except Exception:
            pass
        await _deliver(url, item)


def log_event(title, fields, status="info", accent=None, ts=None,
              thumbnail_url=None):
    """Fire-and-forget audit record. Safe to call from anywhere, any time.

    `accent` is accepted for call-site compatibility and deliberately ignored:
    containers are monochrome.
    """
    global _audit_queue
    if _audit_queue is None:
        try:
            _audit_queue = asyncio.Queue(maxsize=_MAX_QUEUE)
        except Exception:
            return
    if _audit_task is None or _audit_task.done():
        try:
            start_audit_worker()
        except Exception:
            pass
    try:
        if _note_seen(_signature(title, fields, status)):
            _stats["deduped"] += 1
            return
        normalized = [[str(l), "" if v is None else _redact(str(v))]
                      for l, v in (fields or [])]
        if not any(str(l).lower() == "session" for l, _ in normalized):
            normalized.append(["session", _SESSION_ID])
        if not any(str(l).lower() == "pid" for l, _ in normalized):
            normalized.append(["pid", str(os.getpid())])
        if not any(str(l).lower() == "source" for l, _ in normalized):
            normalized.append(["source", _caller_source()])
        _audit_queue.put_nowait({"title": _redact(str(title)),
                                 "fields": normalized,
                                 "status": status,
                                 "ts": ts or _now(),
                                 "thumbnail_url": _redact(str(thumbnail_url or ""))})
        _stats["queued"] += 1
    except asyncio.QueueFull:
        _stats["dropped"] += 1
        _spill([{ "title": _redact(str(title)), "fields": normalized,
                  "status": status, "ts": ts or _now()}])
    except Exception:
        _stats["dropped"] += 1


def start_audit_worker():
    global _audit_queue, _audit_task
    if _audit_queue is None:
        _audit_queue = asyncio.Queue(maxsize=_MAX_QUEUE)
        recovered = _recover_spill()
        if recovered:
            _warn(f"audit logger: recovered {recovered} undelivered event(s) "
                  "from the previous session")
    if _audit_task is None or _audit_task.done():
        _audit_task = asyncio.get_running_loop().create_task(_audit_worker())
    return _audit_task


async def stop_audit_worker(flush=True, timeout=5.0):
    """Flush what we can, spill the rest, then stop. Called on shutdown."""
    global _audit_task, _session
    task, _audit_task = _audit_task, None
    if flush and _audit_queue is not None:
        try:
            await asyncio.wait_for(_audit_queue.join(), timeout=timeout)
        except Exception:
            pass
    if task is not None:
        task.cancel()
        try:
            await asyncio.wait_for(asyncio.gather(task, return_exceptions=True), timeout=2.0)
        except Exception:
            pass
    leftover = list(_parked) + _drain_queue()
    _parked.clear()
    _spill(leftover)
    if _session is not None:
        try:
            await _session.close()
        except Exception:
            pass
        _session = None


def spill_now():
    """Synchronous best-effort flush for signal handlers / atexit hooks."""
    try:
        leftover = list(_parked) + _drain_queue()
        _parked.clear()
        _spill(leftover)
        return len(leftover)
    except Exception:
        return 0


def delivery_stats():
    return {
        "webhook": bool(_webhook_url()),
        "running": bool(_audit_task is not None and not _audit_task.done()),
        "queued": _audit_queue.qsize() if _audit_queue else 0,
        "parked": len(_parked),
        "dead": len(_dead),
        "session": _SESSION_ID,
        "dead_items": [
            {"title": (d.get("item") or {}).get("title"),
             "error": d.get("error"), "ts": d.get("ts")}
            for d in list(_dead)[-10:]
        ],
        **_stats,
    }


def retry_dead():
    """Re-queue every dead-lettered record. Returns how many were restored."""
    n = 0
    while _dead:
        try:
            rec = _dead.popleft()
        except Exception:
            break
        it = rec.get("item") if isinstance(rec, dict) else None
        if isinstance(it, dict) and _audit_queue is not None:
            try:
                _audit_queue.put_nowait(it)
                n += 1
            except Exception:
                pass
    return n


def _read_session_state():
    try:
        with open(_SESSION_PATH, "r", encoding="utf-8") as f:
            value = json.load(f)
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _write_session_state(value):
    try:
        os.makedirs(os.path.dirname(_SESSION_PATH), exist_ok=True)
        with open(_SESSION_PATH, "w", encoding="utf-8") as f:
            json.dump(value, f, ensure_ascii=False)
    except Exception:
        pass


def session_started(reason="fresh start"):
    """Call only after Discord's ready event confirms a real session."""
    previous = _read_session_state()
    _write_session_state({"session": _SESSION_ID, "pid": os.getpid(),
                          "started": time.time(), "status": "running"})
    fields = [("event", "SESSION_STARTED"), ("reason", reason),
              ("uptime", "0s"), ("version", getattr(S, "VERSION", "?"))]
    if previous:
        fields.extend([("previous session", previous.get("session", "unknown")),
                       ("previous status", previous.get("status", "unknown")),
                       ("restart reason", previous.get("reason", "-"))])
    log_event("BOT_STARTUP", fields, status="ok")


def session_ended(reason, status="warn"):
    """Persist shutdown before exec/signal termination when awaiting is impossible."""
    _write_session_state({"session": _SESSION_ID, "pid": os.getpid(),
                          "started": _PROCESS_STARTED, "ended": time.time(),
                          "status": "ended", "reason": _redact(reason)})
    _spill([{ "title": "BOT_SHUTDOWN", "fields": [["event", "SESSION_ENDED"],
             ["reason", _redact(reason)], ["session", _SESSION_ID],
             ["pid", str(os.getpid())]], "status": status, "ts": _now()}])


# ─────────────────────────────────────────────
# channel loggers (unchanged behaviour)
# ─────────────────────────────────────────────

def _sync(**kw):
    main = sys.modules.get("__main__")
    if main is None:
        return
    for k, v in kw.items():
        try:
            setattr(main, k, v)
        except Exception:
            pass


def _log_ch(client, kind):
    ch_id = S.loggers.get(kind, {}).get("channel")
    if not ch_id:
        return None
    try:
        return client.get_channel(int(ch_id))
    except Exception:
        return None


def _fmt_time():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _author_avatar(author):
    """Return a usable avatar URL, including Discord's default avatar."""
    return (getattr(author, "display_avatar_url", None)
            or getattr(author, "avatar_url", None)
            or None)


def _deleted_components(message):
    """Render the compact deleted-message card used by loggers and snipes."""
    author_id = getattr(getattr(message, "author", None), "id", "?")
    content = (getattr(message, "content", "") or "<no text content>")[:3600]
    stamp = int(time.time())
    return [{"type": 17, "components": [
        {"type": 9, "components": [
            {"type": 10, "content": f"<@{author_id}> deleted this message <t:{stamp}:F>"},
            {"type": 10, "content": f"**__{content}__**"},
        ], "accessory": {"type": 11, "media": {
            "url": _author_avatar(getattr(message, "author", None)) or _THUMBNAIL_URL}}},
    ]}]


def _mentions_self(client, m):
    try:
        if client.user and any(
                getattr(u, "id", None) == client.user.id for u in (m.mentions or [])):
            return True
    except Exception:
        pass
    try:
        raw = getattr(m, "raw_mentions", None)
        if raw and client.user and client.user.id in raw:
            return True
    except Exception:
        pass
    return False


async def _emit(client, kind, title, rows):
    ch = _log_ch(client, kind)
    if not ch:
        return
    try:
        await ch.send(S.ui_box(title, rows))
    except Exception:
        pass


class LoggersCog:
    COMMANDS = {"logger", "logchannel", "logstatus", "logdead", "logflush",
                "clearlogs",
                "logmessage", "logdeleted", "logedited", "logreaction",
                "logmention", "logdm", "logjoins", "logleaves"}

    def register(self, client):
        cog = self
        try:
            S.log_event = log_event
        except Exception:
            pass
        try:
            start_audit_worker()
        except Exception as e:
            _warn(f"audit logger failed to start: {e}")

        @client.event
        async def on_message(m):
            if getattr(m.author, "id", None) == client.user.id: return
            if S.loggers["mention"]["enabled"] and _mentions_self(client, m):
                await cog._mention(m)
            if S.loggers["dm"]["enabled"] and getattr(m, "guild", None) is None:
                await cog._dm(m)
            if not S.loggers["message"]["enabled"]: return
            await cog._message(m)

        @client.event
        async def on_message_delete(m):
            if not S.loggers["deleted"]["enabled"]: return
            if getattr(m.author, "id", None) == client.user.id: return
            await cog._deleted(m)

        @client.event
        async def on_message_edit(before, after):
            if not S.loggers["edited"]["enabled"]: return
            if getattr(before.author, "id", None) == client.user.id: return
            if (before.content or "") == (after.content or ""): return
            await cog._edited(before, after)

        @client.event
        async def on_reaction_add(reaction, user):
            if not S.loggers["reaction"]["enabled"]: return
            if getattr(user, "id", None) == client.user.id: return
            await cog._reaction(reaction, user, add=True)

        @client.event
        async def on_reaction_remove(reaction, user):
            if not S.loggers["reaction"]["enabled"]: return
            if getattr(user, "id", None) == client.user.id: return
            await cog._reaction(reaction, user, add=False)

        @client.event
        async def on_member_join(member):
            if not S.loggers["joins"]["enabled"]: return
            await _emit(client, "joins", "member join", [
                f"  {S.DIM}user{S.RESET}  {member}  ({getattr(member, 'id', '?')})",
                f"  {S.DIM}guild{S.RESET} {getattr(getattr(member, 'guild', None), 'name', '?')}",
                f"  {S.DIM}at{S.RESET}    {_fmt_time()}",
            ])

        @client.event
        async def on_member_remove(member):
            if not S.loggers["leaves"]["enabled"]: return
            await _emit(client, "leaves", "member leave", [
                f"  {S.DIM}user{S.RESET}  {member}  ({getattr(member, 'id', '?')})",
                f"  {S.DIM}guild{S.RESET} {getattr(getattr(member, 'guild', None), 'name', '?')}",
                f"  {S.DIM}at{S.RESET}    {_fmt_time()}",
            ])

    async def _message(self, m):
        g = getattr(m, "guild", None)
        rows = [
            f"  {S.DIM}guild{S.RESET}   {getattr(g, 'name', 'DM')}",
            f"  {S.DIM}channel{S.RESET} {getattr(m.channel, 'name', str(m.channel_id))}",
            f"  {S.DIM}author{S.RESET}  {m.author}  ({getattr(m.author,'id','?')})",
            f"  {S.DIM}at{S.RESET}      {_fmt_time()}",
            "",
            f"  {S.WHITE}{(m.content or '')[:400]}{S.RESET}",
        ]
        await _emit(S.CLIENT, "message", "message", rows)

    async def _mention(self, m):
        g = getattr(m, "guild", None)
        rows = [
            f"  {S.DIM}guild{S.RESET}   {getattr(g, 'name', 'DM')}",
            f"  {S.DIM}channel{S.RESET} {getattr(m.channel, 'name', str(m.channel_id))}",
            f"  {S.DIM}author{S.RESET}  {m.author}  ({getattr(m.author,'id','?')})",
            f"  {S.DIM}at{S.RESET}      {_fmt_time()}",
            "",
            f"  {S.WHITE}{(m.content or '')[:400]}{S.RESET}",
        ]
        await _emit(S.CLIENT, "mention", "mention", rows)

    async def _dm(self, m):
        rows = [
            f"  {S.DIM}author{S.RESET}  {m.author}  ({getattr(m.author,'id','?')})",
            f"  {S.DIM}at{S.RESET}      {_fmt_time()}",
            "",
            f"  {S.WHITE}{(m.content or '')[:400]}{S.RESET}",
        ]
        await _emit(S.CLIENT, "dm", "dm", rows)

    async def _deleted(self, m):
        ch = _log_ch(S.CLIENT, "deleted")
        if not ch:
            return
        try:
            await ch.send(None, flags=_IS_COMPONENTS_V2,
                          components=_deleted_components(m))
        except Exception:
            # Preserve a readable logger entry if a client cannot send V2.
            await _emit(S.CLIENT, "deleted", "message deleted", [
                f"  {S.DIM}author{S.RESET}  {m.author}  ({getattr(m.author, 'id', '?')})",
                f"  {S.WHITE}{(m.content or '')[:400]}{S.RESET}",
            ])

    async def _edited(self, before, after):
        rows = [
            f"  {S.DIM}author{S.RESET}  {before.author}  ({getattr(before.author,'id','?')})",
            f"  {S.DIM}channel{S.RESET} {getattr(before.channel, 'name', str(before.channel_id))}",
            f"  {S.DIM}at{S.RESET}      {_fmt_time()}",
            "",
            f"  {S.DIM}before{S.RESET}",
            f"  {S.WHITE}{(before.content or '')[:400]}{S.RESET}",
            "",
            f"  {S.DIM}after{S.RESET}",
            f"  {S.WHITE}{(after.content or '')[:400]}{S.RESET}",
        ]
        await _emit(S.CLIENT, "edited", "message edited", rows)

    async def _reaction(self, reaction, user, add=True):
        try:
            msg = reaction.message
        except Exception:
            return
        rows = [
            f"  {S.DIM}user{S.RESET}    {user}  ({getattr(user,'id','?')})",
            f"  {S.DIM}emoji{S.RESET}   {reaction.emoji}",
            f"  {S.DIM}action{S.RESET}  {'added' if add else 'removed'}",
            f"  {S.DIM}channel{S.RESET} {getattr(msg.channel, 'name', str(getattr(msg,'channel_id','?')))}",
            f"  {S.DIM}at{S.RESET}      {_fmt_time()}",
            "",
            f"  {S.WHITE}{(getattr(msg, 'content', '') or '')[:200]}{S.RESET}",
        ]
        await _emit(S.CLIENT, "reaction", "reaction", rows)

    async def handle(self, message, cmd, args):
        if cmd == "logger":
            sub = args[1].lower() if len(args) > 1 else ""
            kinds = list(S.loggers.keys())
            if sub in kinds:
                kind = sub
                on = (args[2].lower() in ("on", "enable")) if len(args) > 2 else not S.loggers[kind]["enabled"]
                S.loggers[kind]["enabled"] = on
                return await message.edit(content=S.ui_ok(f"{kind} logger → {on}"))
            if sub == "all":
                on = (args[2].lower() in ("on", "enable")) if len(args) > 2 else True
                for k in kinds:
                    S.loggers[k]["enabled"] = on
                return await message.edit(content=S.ui_ok(f"all loggers → {on}"))
            if sub in ("on", "off", "enable", "disable"):
                S.LOGGER_ENABLED = sub in ("on", "enable")
                _sync(LOGGER_ENABLED=S.LOGGER_ENABLED)
                return await message.edit(content=S.ui_ok(
                    f"logger → {'ON' if S.LOGGER_ENABLED else 'OFF'}"))
            rows = [f"  {S.DIM}{k:<10}{S.RESET}  {'ON' if v['enabled'] else 'off'}  "
                    f"{S.DIM}{v['channel'] or '—'}{S.RESET}" for k, v in S.loggers.items()]
            return await message.edit(content=S.ui_box("loggers", rows))

        if cmd == "logchannel":
            if len(args) < 3:
                return await message.edit(content=S.ui_err("usage: logchannel <kind> <ch_id>"))
            kind = args[1].lower()
            if kind not in S.loggers:
                return await message.edit(content=S.ui_err(f"unknown kind: {kind}"))
            S.loggers[kind]["channel"] = args[2]
            await message.edit(content=S.ui_ok(f"{kind} → {args[2]}"))

        if cmd == "logstatus":
            rows = [f"  {S.DIM}{k:<10}{S.RESET}  {'ON ' if v['enabled'] else 'off'}  ch {v['channel'] or '—'}"
                    for k, v in S.loggers.items()]
            st = delivery_stats()
            rows.append("")
            rows.append(f"  {S.DIM}audit webhook {S.RESET}  {'set' if st['webhook'] else 'NOT SET'}")
            rows.append(f"  {S.DIM}worker        {S.RESET}  {'running' if st['running'] else 'stopped'}")
            rows.append(f"  {S.DIM}queued/parked {S.RESET}  {st['queued']} / {st['parked']}")
            rows.append(f"  {S.DIM}sent/failed   {S.RESET}  {st['sent']} / {st['failed']}")
            rows.append(f"  {S.DIM}dead letter   {S.RESET}  {st['dead']}")
            if st.get("last_error"):
                rows.append(f"  {S.DIM}last error    {S.RESET}  "
                            f"{S.redact_secrets(str(st['last_error']))[:90]}")
            return await message.edit(content=S.ui_box("loggers status", rows))

        if cmd == "logdead":
            st = delivery_stats()
            items = st.get("dead_items") or []
            if not items:
                return await message.edit(content=S.ui_ok("no undelivered audit records"))
            rows = [f"  {S.DIM}{datetime.fromtimestamp(i['ts']).strftime('%H:%M:%S')}{S.RESET}  "
                    f"{i.get('title')}  {S.DIM}{S.redact_secrets(str(i.get('error')))[:50]}{S.RESET}"
                    for i in items]
            return await message.edit(content=S.ui_box(f"undelivered ({st['dead']})", rows))

        if cmd == "logflush":
            n = retry_dead()
            await message.edit(content=S.ui_ok(
                f"re-queued {n} undelivered record(s) for another attempt"))

        if cmd == "clearlogs":
            held = len(_dead) + len(_parked)
            _dead.clear()
            _parked.clear()
            for path in (_SPILL_PATH, S.LOG_FILE):
                try:
                    if os.path.exists(path):
                        with open(path, "w"):
                            pass
                except Exception:
                    pass
            await message.edit(content=S.ui_ok(
                f"dropped {held} held record(s) and truncated the log file"))

        elif cmd.startswith("log") and cmd[3:] in S.loggers:
            kind = cmd[3:]
            on = (args[1].lower() in ("on", "enable")) if len(args) > 1 else not S.loggers[kind]["enabled"]
            S.loggers[kind]["enabled"] = on
            await message.edit(content=S.ui_ok(f"{kind} → {on}"))
